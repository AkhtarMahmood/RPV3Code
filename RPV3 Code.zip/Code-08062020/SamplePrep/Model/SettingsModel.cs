﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SamplePrep.Resources;
using System.IO.Ports;
using System.Windows.Threading;
using System.Windows;

namespace SamplePrep.Model
{
    class SettingsModel : ObservableObject
    {
        #region Fields
        /// <summary>
        /// Private fields
        /// </summary>
        private string _bathNumber;
        private string _units;
        private string _setPoint;
        private double _currentSetPoint;
        private double _currentOffset;
        private string _coolingMode;

        //Measurement Settings Parameters
        private string _kECorrection;
        private string _maxFlowTimes;
        private string _testMode;
        private string _drainTime;
        private string _equilibriumTime;
        private string _percentageOverfill;
        private string _voidRun;

        //Cleaning settings parameters
        private string _dryingTimeCycles;
        private string _dryingTimeSeconds;
        private string _extractionTimeCycles;
        private string _extractionTimeSeconds;
        private string _solventTimeCycles;
        private string _solventTimeSeconds;



        //public RS485NMEA RS485NMEATCM = new RS485NMEA();
        #endregion

        #region Public properties
        /// <summary>
        /// Bath Number public property 
        /// </summary>
        public string BathNumber
        {
            get => _bathNumber;
            set
            {
                if (_bathNumber != value)
                {
                    _bathNumber = value;
                    OnPropertyChanged("BathNumber");
                }
            }
        }

        /// <summary>
        /// Set point public property
        /// </summary>
        public string Setpoint
        {
            get => _setPoint;
            set
            {
                if (_setPoint != value)
                {
                    _setPoint = value;
                    OnPropertyChanged("SetPoint");
                }

            }
        }
        /// <summary>
        /// Set point public property
        /// </summary>
        public double CurrentSetpoint
        {
            get => _currentSetPoint;
            set
            {
                if (_currentSetPoint != value)
                {
                    _currentSetPoint = value;
                    OnPropertyChanged("CurrentSetPoint");
                }

            }
        }

        /// <summary>
        /// Set point public property
        /// </summary>
        public double CurrentOffset
        {
            get => _currentOffset;
            set
            {
                if (_currentOffset != value)
                {
                    _currentOffset = value;
                    OnPropertyChanged("CurrentOffset");
                }

            }
        }

        /// <summary>
        /// Actual temperature public property
        /// </summary>
        public string Units
        {
            get => _units;
            set
            {
                if (_units != value)
                {
                    _units = value;
                    OnPropertyChanged("Units");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string CoolingMode
        {
            get => _coolingMode;
            set
            {
                if (_coolingMode != value)
                {
                    _coolingMode = value;
                    OnPropertyChanged("CoolingMode");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string KECorrection
        {
            get => _kECorrection;
            set
            {
                if (_kECorrection != value)
                {
                    _kECorrection = value;
                    OnPropertyChanged("KECorrection");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string MaxFlowTimes
        {
            get => _maxFlowTimes;
            set
            {
                if (_maxFlowTimes != value)
                {
                    _maxFlowTimes = value;
                    OnPropertyChanged("MaxFlowTimes");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string TestMode
        {
            get => _testMode;
            set
            {
                if (_testMode != value)
                {
                    _testMode = value;
                    OnPropertyChanged("TestMode");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string DrainTime
        {
            get => _drainTime;
            set
            {
                if (_drainTime != value)
                {
                    _drainTime = value;
                    OnPropertyChanged("DrainTime");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string EquilibriumTime
        {
            get => _equilibriumTime;
            set
            {
                if (_equilibriumTime != value)
                {
                    _equilibriumTime = value;
                    OnPropertyChanged("EquilibriumTime");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string PercentageOverfill
        {
            get => _percentageOverfill;
            set
            {
                if (_percentageOverfill != value)
                {
                    _percentageOverfill = value;
                    OnPropertyChanged("PercentageOverfill");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string VoidRun
        {
            get => _voidRun;
            set
            {
                if (_voidRun != value)
                {
                    _voidRun = value;
                    OnPropertyChanged("VoidRun");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string DryingTimeCycles
        {
            get => _dryingTimeCycles;
            set
            {
                if (_dryingTimeCycles != value)
                {
                    _dryingTimeCycles = value;
                    OnPropertyChanged("DryingTimeCycles");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string DryingTimeSeconds
        {
            get => _dryingTimeSeconds;
            set
            {
                if (_dryingTimeSeconds != value)
                {
                    _dryingTimeSeconds = value;
                    OnPropertyChanged("DryingTimeSeconds");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string ExtractionTimeCycles
        {
            get => _extractionTimeCycles;
            set
            {
                if (_extractionTimeCycles != value)
                {
                    _extractionTimeCycles = value;
                    OnPropertyChanged("ExtractionTimeCycles");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string ExtractionTimeSeconds
        {
            get => _extractionTimeSeconds;
            set
            {
                if (_extractionTimeSeconds != value)
                {
                    _extractionTimeSeconds = value;
                    OnPropertyChanged("ExtractionTimeSeconds");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string SolventTimeCycles
        {
            get => _solventTimeCycles;
            set
            {
                if (_solventTimeCycles != value)
                {
                    _solventTimeCycles = value;
                    OnPropertyChanged("SolventTimeCycles");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string SolventTimeSeconds
        {
            get => _solventTimeSeconds;
            set
            {
                if (_solventTimeSeconds != value)
                {
                    _solventTimeSeconds = value;
                    OnPropertyChanged("SolventTimeSeconds");
                }
            }
        }

        
        #endregion

        #region Constructor
        public SettingsModel()
        {

        }
        #endregion
    }
}
