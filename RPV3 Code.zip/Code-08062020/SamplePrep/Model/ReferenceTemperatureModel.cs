﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SamplePrep.Resources;
using System.IO.Ports;
using System.Windows.Threading;
using System.Windows;

namespace SamplePrep.Model
{
    class ReferenceTemperatureModel : ObservableObject
    {
        #region Fields
        /// <summary>
        /// Private fields
        /// </summary>
        private string _bathNumber;
        private double _setPoint;
        private double _actual;
        private string _reference;
        private string _status;
        private double _offset;

        //public RS485NMEA RS485NMEATCM = new RS485NMEA();
        #endregion

        #region Public properties
        /// <summary>
        /// Bath Number public property 
        /// </summary>
        public string BathNumber
        {
            get => _bathNumber;
            set
            {
                if(_bathNumber != value)
                {
                    _bathNumber = value;
                    OnPropertyChanged("BathNumber");
                }
            }
        }

        /// <summary>
        /// Set point public property
        /// </summary>
        public double Setpoint
        {
            get => _setPoint;
            set
            {
                if(_setPoint != value)
                {
                    _setPoint = value;
                    OnPropertyChanged("SetPoint");
                }
                
            }
        }

        /// <summary>
        /// Actual temperature public property
        /// </summary>
        public double Actual
        {
            get => _actual;
            set
            {
                if (_actual != value)
                {
                    _actual = value;
                    OnPropertyChanged("Actual");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string Reference
        {
            get => _reference;
            set
            {
                if(_reference != value)
                {
                    _reference = value;
                    OnPropertyChanged("Reference");
                }
            }
        }

        /// <summary>
        /// Status of bath (On/Off) public property
        /// </summary>
        public string Status
        {
            get => _status;
            set
            {
                if(_status != value)
                {
                    _status = value;
                    OnPropertyChanged("Status");
                }
            }
        }

        /// <summary>
        /// Bath Offset public property
        /// </summary>
        public double Offset
        {
            get => _offset;
            set
            {
                if(_offset != value)
                {
                    _offset = value;
                    OnPropertyChanged("Offset");
                }
            }
        }

        #endregion

        #region Constructor
        public ReferenceTemperatureModel()
        {
            
        }
    
        #endregion
    }
}
