﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SamplePrep.Resources;

namespace SamplePrep.Model
{
    class ViscometerMeasurementModel : ObservableObject
    {

        /// <summary>
        /// Private Model Variables 
        /// </summary>
        private string _sampleType;
        private string _userName;
        private string _sampleName;
        private string _concentration;
        private string _description;
        private string _solventFlowTime;
        private string _dryMatter;
        private string _insoluble;
        private string _solventVolume;
        private string _density;
        private string _flowTime;
        private string _viscometer;


        /// <summary>
        /// Public property of _sampleType Variable with event generation
        /// </summary>
        public string SampleType
        {
            get => _sampleType;
            set
            {
                if (_sampleType != value)
                {
                    _sampleType = value;
                    OnPropertyChanged("SampleType");
                }
            }
        }

        public string UserName
        {
            get => _userName;
            set
            {
                if (_userName != value)
                {
                    _userName = value;
                    OnPropertyChanged("UserName");
                }
            }
        }

        public string SampleName
        {
            get => _sampleName;
            set
            {
                if (_sampleName != value)
                {
                    _sampleName = value;
                    OnPropertyChanged("SampleName");
                }
            }
        }

        public string Concentration
        {
            get => _concentration;
            set
            {
                if (_concentration != value)
                {
                    _concentration = value;
                    OnPropertyChanged("Concentration");
                }
            }
        }

        public string Description
        {
            get => _description;
            set
            {
                if (_description != value)
                {
                    _description = value;
                    OnPropertyChanged("Description");
                }
            }
        }

        public string SolventFlowTime
        {
            get => _solventFlowTime;
            set
            {
                if (_solventFlowTime != value)
                {
                    _solventFlowTime = value;
                    OnPropertyChanged("SampleWeight");
                }
            }
        }

        public string DryMatter
        {
            get => _dryMatter;
            set
            {
                if (_dryMatter != value)
                {
                    _dryMatter = value;
                    OnPropertyChanged("DryMatter");
                }
            }
        }

        public string Insoluble
        {
            get => _insoluble;
            set
            {
                if (_insoluble != value)
                {
                    _insoluble = value;
                    OnPropertyChanged("Insoluble");
                }
            }
        }

        public string SolventVolume
        {
            get => _solventVolume;
            set
            {
                if (_solventVolume != value)
                {
                    _solventVolume = value;
                    OnPropertyChanged("SolventVolume");
                }
            }
        }

        public string Density
        {
            get => _density;
            set
            {
                if (_density != value)
                {
                    _density = value;
                    OnPropertyChanged("Density");
                }
            }
        }

        public string FlowTime
        {
            get => _flowTime;
            set
            {
                if (_flowTime != value)
                {
                    _flowTime = value;
                    OnPropertyChanged("FlowTime");
                }
            }
        }

        public string Viscometer
        {
            get => _viscometer;
            set
            {
                if (_viscometer != value)
                {
                    _viscometer = value;
                    OnPropertyChanged("Viscometer");
                }
            }
        }

    }
}
