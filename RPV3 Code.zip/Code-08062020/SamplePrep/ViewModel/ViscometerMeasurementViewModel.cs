﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SamplePrep.Resources;
using SamplePrep.Model;
using System.Windows.Threading;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Diagnostics;
using System.Globalization;

namespace SamplePrep.ViewModel
{
    class ViscometerMeasurementViewModel : ObservableObject
    {
        #region Define objects of ReferenceTemperature Model and RS485NMEATCM class

        // Object of the Reference Temperature Model Class
        //ReferenceTemperatureModel _referenceTemperatureModel = new ReferenceTemperatureModel();
        //Object of the RS485 class


        //Create an object of RS485NMEATCM communication
        //RS485NMEATCM RS485NMEATCM = new RS485NMEATCM();
        //RS485NMEATCM

        //CheckBox Commands
        public RelayCommand EnableCheckBoxCommand { get; set; }
        //Object of Relay command to execute on OK button press
        public RelayCommand StartMeasurementButtonCommand1 { get; set; }
        public RelayCommand StartMeasurementButtonCommand2 { get; set; }
        public RelayCommand StartMeasurementButtonCommand3 { get; set; }
        public RelayCommand StartMeasurementButtonCommand4 { get; set; }
        //Object of Relay command to execute on OK button press
        public RelayCommand AbortButtonCommand1 { get; set; }
        public RelayCommand AbortButtonCommand2 { get; set; }
        public RelayCommand AbortButtonCommand3 { get; set; }
        public RelayCommand AbortButtonCommand4 { get; set; }
        //Object of Address class for the addressing of temperature control bath
        public AddressingAndCommands AddrnComm = new AddressingAndCommands();

        public ViscometerMeasurementModel _viscometerMeasurementModel1 = new ViscometerMeasurementModel();
        public ViscometerMeasurementModel _viscometerMeasurementModel2 = new ViscometerMeasurementModel();
        public ViscometerMeasurementModel _viscometerMeasurementModel3 = new ViscometerMeasurementModel();
        public ViscometerMeasurementModel _viscometerMeasurementModel4 = new ViscometerMeasurementModel();
        //1 ms timer to wait before sending next commands
        public DispatcherTimer timer1 = new DispatcherTimer();

        public DispatcherTimer overFillTimer1 = new DispatcherTimer();

        public DispatcherTimer cleaningTimer1 = new DispatcherTimer();

        public DispatcherTimer timer2 = new DispatcherTimer();
        public DispatcherTimer overFillTimer2 = new DispatcherTimer();

        public DispatcherTimer timer3 = new DispatcherTimer();
        public DispatcherTimer overFillTimer3 = new DispatcherTimer();

        public DispatcherTimer timer4 = new DispatcherTimer();
        public DispatcherTimer overFillTimer4 = new DispatcherTimer();

        public DispatcherTimer timerRestart = new DispatcherTimer();

        public DispatcherTimer timerStateMachine = new DispatcherTimer();
        //Object to perform locking operations between threads
        public static object x = new object();

        //This variable stores the current state of the system
        public int state1 = 0;
        public int state2 = 0;
        public int state3 = 0;
        public int state4 = 0;

        //This variable stores the value of the current timer count in the hardware 
        public double currentTimer1;
        public double currentTimer2;
        public double currentTimer3;
        public double currentTimer4;

        //This function contains the timer value obtained from the hardware from
        public double previousTimer1;
        public double previousTimer2;
        public double previousTimer3;
        public double previousTimer4;

        //This variables checks if the timer value has stopped changing 
        public bool timerDone1 = false;
        public bool timerDone2 = false;
        public bool timerDone3 = false;
        public bool timerDone4 = false;

        Context context = new Context(new ConcreteStateIdle());
        private string flowTime1 = String.Empty;
        private string flowTime2 = String.Empty;
        private string flowTime3 = String.Empty;
        private string flowTime4 = String.Empty;

        public bool abortState1 = false;
        public bool canAbort1 = false;
        public bool canStart1 = true;
        public bool startState1 = false;

        public bool abortState2 = false;
        public bool canAbort2 = false;
        public bool canStart2 = true;
        public bool startState2 = false;

        public bool abortState3 = false;
        public bool canAbort3 = false;
        public bool canStart3 = true;
        public bool startState3 = false;

        public bool abortState4 = false;
        public bool canAbort4 = false;
        public bool canStart4 = true;
        public bool startState4 = false;

        public bool enableCheckBox1 = false;
        public bool sampleLoadedCheckBox1 = false;
        public bool cleaningCheckBox1 = false;
        public bool stationCappedCheckBox1 = false;
        public bool readyToLoadInverted1 = false;

        public bool enableCheckBox2 = false;
        public bool sampleLoadedCheckBox2 = false;
        public bool stationCappedCheckBox2 = false;
        public bool readyToLoadInverted2 = false;

        public bool bathStable = false;
        public static bool timerReset = false;

        Thread firstHalfThread1, secondHalfThread1;
        Thread firstHalfThread2, secondHalfThread2;
        Thread firstHalfThread3, secondHalfThread3;
        Thread firstHalfThread4, secondHalfThread4;

        Thread CleanThread1;

        public string address = null;
        public string unit = null;

        string measurementAddress = null;
        string resetTimerCommand = null;
        string getTimerCommand = null;
        string measurementPositionCommand = null;
        string resetHeadCommand = null;

        public int noOfFlowTimes = Convert.ToInt32(GlobalParameters.maxFlowTimes);
        public int flowTimesCount = 0;
        public double[] flowTimes;

        public string MeasurementLoops = "3.000000";
        public double KEFactor = 24.744169;
        public double viscometerConstant = 0.048;
        public double drainTime = Convert.ToDouble(GlobalParameters.drainTime);
        public double equilibriumTime = Convert.ToDouble(GlobalParameters.equilibriumTime);
        public double percentageOverfill = Convert.ToDouble(GlobalParameters.percentageOverfill);
        public string testMode;
        public string voidRun;
        public string kECorrectioMode;

        public string currentState = null;
        public string previousState = null;
        public string nextState = null;

        public int delayMS = 150;
        public string bathAddress = "128";
        public string positionAddress = "134";



        #endregion

        #region Properties for Viscometer 1

        public bool EnableCheckBox1
        {
            get => enableCheckBox1;
            set
            {
                if (enableCheckBox1 != value)
                {
                    enableCheckBox1 = value;
                    OnPropertyChanged("EnableCheckBox1");
                    Debug.WriteLine("EnableCheckBox1");
                    //ReadyToLoadInverted = !readyToLoad;
                }

            }
        }

        public bool CleaningCheckBox1
        {
            get => cleaningCheckBox1;
            set
            {
                if (cleaningCheckBox1 != value)
                {
                    cleaningCheckBox1 = value;
                    OnPropertyChanged("CleaningCheckBox1");
                    Debug.WriteLine(CleaningCheckBox1);
                    Debug.WriteLine(DateTime.Now.ToString("dd-MM-yyyy") + " \n " + DateTime.Now.ToString("hh:mm:ss") + "\n" + DateTime.Now.Day);

                }
            }
        }

        public bool StationCappedCheckBox1
        {
            get => stationCappedCheckBox1;
            set
            {
                if (stationCappedCheckBox1 != value)
                {
                    stationCappedCheckBox1 = value;
                    OnPropertyChanged("StationCappedCheckBox1");
                    Debug.WriteLine("StationCappedCheckBox1");
                }
            }
        }

        public bool SampleLoadedCheckBox1
        {
            get => sampleLoadedCheckBox1;
            set
            {
                if (sampleLoadedCheckBox1 != value)
                {
                    sampleLoadedCheckBox1 = value;
                    OnPropertyChanged("SampleLoadedCheckBox1");
                    Debug.WriteLine("SampleLoadedCheckBox1");
                }
            }
        }

        public bool EnableCheckBox2
        {
            get => enableCheckBox2;
            set
            {
                if (enableCheckBox2 != value)
                {
                    enableCheckBox2 = value;
                    OnPropertyChanged("EnableCheckBox2");
                    Debug.WriteLine("EnableCheckBox2");
                    //ReadyToLoadInverted = !readyToLoad;
                }

            }
        }

        public bool StationCappedCheckBox2
        {
            get => stationCappedCheckBox2;
            set
            {
                if (stationCappedCheckBox2 != value)
                {
                    stationCappedCheckBox2 = value;
                    OnPropertyChanged("StationCappedCheckBox2");
                    Debug.WriteLine("StationCappedCheckBox2");
                }
            }
        }

        public bool SampleLoadedCheckBox2
        {
            get => sampleLoadedCheckBox2;
            set
            {
                if (sampleLoadedCheckBox2 != value)
                {
                    sampleLoadedCheckBox2 = value;
                    OnPropertyChanged("SampleLoadedCheckBox2");
                    Debug.WriteLine("SampleLoadedCheckBox2");
                }
            }
        }

        public string txtSampleType1
        {
            get => _viscometerMeasurementModel1.SampleType;
            set
            {
                if (_viscometerMeasurementModel1.SampleType != value)
                {
                    _viscometerMeasurementModel1.SampleType = value;
                    OnPropertyChanged("txtSampleType1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }


        public string txtUserName1
        {
            get => _viscometerMeasurementModel1.UserName;
            set
            {
                if (_viscometerMeasurementModel1.UserName != value)
                {
                    _viscometerMeasurementModel1.UserName = value;
                    OnPropertyChanged("txtUserName1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSampleName1
        {
            get => _viscometerMeasurementModel1.SampleName;
            set
            {
                if (_viscometerMeasurementModel1.SampleName != value)
                {
                    _viscometerMeasurementModel1.SampleName = value;
                    OnPropertyChanged("txtSampleName1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtConcentration1
        {
            get => _viscometerMeasurementModel1.Concentration;
            set
            {
                if (_viscometerMeasurementModel1.Concentration != value)
                {
                    _viscometerMeasurementModel1.Concentration = value;
                    OnPropertyChanged("txtConcentration1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDescription1
        {
            get => _viscometerMeasurementModel1.Description;
            set
            {
                if (_viscometerMeasurementModel1.Description != value)
                {
                    _viscometerMeasurementModel1.Description = value;
                    OnPropertyChanged("txtDescription1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSolventFlowTime1
        {
            get => _viscometerMeasurementModel1.SolventFlowTime;
            set
            {
                if (_viscometerMeasurementModel1.SolventFlowTime != value)
                {
                    _viscometerMeasurementModel1.SolventFlowTime = value;
                    OnPropertyChanged("txtSolventFlowTime1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtViscometer1
        {
            get => _viscometerMeasurementModel1.Viscometer;
            set
            {
                if (_viscometerMeasurementModel1.Viscometer != value)
                {
                    _viscometerMeasurementModel1.Viscometer = value;
                    OnPropertyChanged("txtViscometer1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtViscometer2
        {
            get => _viscometerMeasurementModel2.Viscometer;
            set
            {
                if (_viscometerMeasurementModel2.Viscometer != value)
                {
                    _viscometerMeasurementModel2.Viscometer = value;
                    OnPropertyChanged("txtViscometer2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }


        public string txtDryMatter1
        {
            get => _viscometerMeasurementModel1.DryMatter;
            set
            {
                if (_viscometerMeasurementModel1.DryMatter != value)
                {
                    _viscometerMeasurementModel1.DryMatter = value;
                    OnPropertyChanged("txtDryMatter1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtInsoluble1
        {
            get => _viscometerMeasurementModel1.Insoluble;
            set
            {
                if (_viscometerMeasurementModel1.Insoluble != value)
                {
                    _viscometerMeasurementModel1.Insoluble = value;
                    OnPropertyChanged("txtInsoluble1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSolventVolume1
        {
            get => _viscometerMeasurementModel1.SolventVolume;
            set
            {
                if (_viscometerMeasurementModel1.SolventVolume != value)
                {
                    _viscometerMeasurementModel1.SolventVolume = value;
                    OnPropertyChanged("txtSolventVolume1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDensity1
        {
            get => _viscometerMeasurementModel1.Density;
            set
            {
                if (_viscometerMeasurementModel1.Density != value)
                {
                    _viscometerMeasurementModel1.Density = value;
                    OnPropertyChanged("txtDensity1");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtFlowTime1
        {
            get => _viscometerMeasurementModel1.FlowTime;

            set
            {
                if (_viscometerMeasurementModel1.FlowTime != value)
                {
                    Debug.WriteLine("flowTime changed = " + value);
                    _viscometerMeasurementModel1.FlowTime = value;
                    OnPropertyChanged("txtFlowTime1");
                }
            }
        }

        #endregion


        #region Properties for Viscometer 2
        public string txtSampleType2
        {
            get => _viscometerMeasurementModel2.SampleType;
            set
            {
                if (_viscometerMeasurementModel2.SampleType != value)
                {
                    _viscometerMeasurementModel2.SampleType = value;
                    OnPropertyChanged("txtSampleType2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }


        public string txtUserName2
        {
            get => _viscometerMeasurementModel2.UserName;
            set
            {
                if (_viscometerMeasurementModel2.UserName != value)
                {
                    _viscometerMeasurementModel2.UserName = value;
                    OnPropertyChanged("txtUserName2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSampleName2
        {
            get => _viscometerMeasurementModel2.SampleName;
            set
            {
                if (_viscometerMeasurementModel2.SampleName != value)
                {
                    _viscometerMeasurementModel2.SampleName = value;
                    OnPropertyChanged("txtSampleName2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtConcentration2
        {
            get => _viscometerMeasurementModel2.Concentration;
            set
            {
                if (_viscometerMeasurementModel2.Concentration != value)
                {
                    _viscometerMeasurementModel2.Concentration = value;
                    OnPropertyChanged("txtConcentration2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDescription2
        {
            get => _viscometerMeasurementModel2.Description;
            set
            {
                if (_viscometerMeasurementModel2.Description != value)
                {
                    _viscometerMeasurementModel2.Description = value;
                    OnPropertyChanged("txtDescription2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSolventFlowTime2
        {
            get => _viscometerMeasurementModel2.SolventFlowTime;
            set
            {
                if (_viscometerMeasurementModel2.SolventFlowTime != value)
                {
                    _viscometerMeasurementModel2.SolventFlowTime = value;
                    OnPropertyChanged("txtSolventFlowTime2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDryMatter2
        {
            get => _viscometerMeasurementModel2.DryMatter;
            set
            {
                if (_viscometerMeasurementModel2.DryMatter != value)
                {
                    _viscometerMeasurementModel2.DryMatter = value;
                    OnPropertyChanged("txtDryMatter2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtInsoluble2
        {
            get => _viscometerMeasurementModel2.Insoluble;
            set
            {
                if (_viscometerMeasurementModel2.Insoluble != value)
                {
                    _viscometerMeasurementModel2.Insoluble = value;
                    OnPropertyChanged("txtInsoluble2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSolventVolume2
        {
            get => _viscometerMeasurementModel2.SolventVolume;
            set
            {
                if (_viscometerMeasurementModel2.SolventVolume != value)
                {
                    _viscometerMeasurementModel2.SolventVolume = value;
                    OnPropertyChanged("txtSolventVolume2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDensity2
        {
            get => _viscometerMeasurementModel2.Density;
            set
            {
                if (_viscometerMeasurementModel2.Density != value)
                {
                    _viscometerMeasurementModel2.Density = value;
                    OnPropertyChanged("txtDensity2");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtFlowTime2
        {
            get => _viscometerMeasurementModel2.FlowTime;

            set
            {
                if (_viscometerMeasurementModel2.FlowTime != value)
                {
                    Debug.WriteLine("flowTime changed = " + value);
                    _viscometerMeasurementModel2.FlowTime = value;
                    OnPropertyChanged("txtFlowTime2");
                }
            }
        }

        #endregion

        #region Properties for Viscometer 3
        public string txtSampleType3
        {
            get => _viscometerMeasurementModel3.SampleType;
            set
            {
                if (_viscometerMeasurementModel3.SampleType != value)
                {
                    _viscometerMeasurementModel3.SampleType = value;
                    OnPropertyChanged("txtSampleType3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }


        public string txtUserName3
        {
            get => _viscometerMeasurementModel3.UserName;
            set
            {
                if (_viscometerMeasurementModel3.UserName != value)
                {
                    _viscometerMeasurementModel3.UserName = value;
                    OnPropertyChanged("txtUserName3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSampleName3
        {
            get => _viscometerMeasurementModel3.SampleName;
            set
            {
                if (_viscometerMeasurementModel3.SampleName != value)
                {
                    _viscometerMeasurementModel3.SampleName = value;
                    OnPropertyChanged("txtSampleName3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtConcentration3
        {
            get => _viscometerMeasurementModel3.Concentration;
            set
            {
                if (_viscometerMeasurementModel3.Concentration != value)
                {
                    _viscometerMeasurementModel3.Concentration = value;
                    OnPropertyChanged("txtConcentration3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDescription3
        {
            get => _viscometerMeasurementModel3.Description;
            set
            {
                if (_viscometerMeasurementModel3.Description != value)
                {
                    _viscometerMeasurementModel3.Description = value;
                    OnPropertyChanged("txtDescription3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSolventFlowTime3
        {
            get => _viscometerMeasurementModel3.SolventFlowTime;
            set
            {
                if (_viscometerMeasurementModel3.SolventFlowTime != value)
                {
                    _viscometerMeasurementModel3.SolventFlowTime = value;
                    OnPropertyChanged("txtSolventFlowTime3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDryMatter3
        {
            get => _viscometerMeasurementModel3.DryMatter;
            set
            {
                if (_viscometerMeasurementModel3.DryMatter != value)
                {
                    _viscometerMeasurementModel3.DryMatter = value;
                    OnPropertyChanged("txtDryMatter3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtInsoluble3
        {
            get => _viscometerMeasurementModel3.Insoluble;
            set
            {
                if (_viscometerMeasurementModel3.Insoluble != value)
                {
                    _viscometerMeasurementModel3.Insoluble = value;
                    OnPropertyChanged("txtInsoluble3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSolventVolume3
        {
            get => _viscometerMeasurementModel3.SolventVolume;
            set
            {
                if (_viscometerMeasurementModel3.SolventVolume != value)
                {
                    _viscometerMeasurementModel3.SolventVolume = value;
                    OnPropertyChanged("txtSolventVolume3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDensity3
        {
            get => _viscometerMeasurementModel3.Density;
            set
            {
                if (_viscometerMeasurementModel3.Density != value)
                {
                    _viscometerMeasurementModel3.Density = value;
                    OnPropertyChanged("txtDensity3");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtFlowTime3
        {
            get => _viscometerMeasurementModel3.FlowTime;

            set
            {
                if (_viscometerMeasurementModel3.FlowTime != value)
                {
                    Debug.WriteLine("flowTime changed = " + value);
                    _viscometerMeasurementModel3.FlowTime = value;
                    OnPropertyChanged("txtFlowTime3");
                }
            }
        }

        #endregion


        #region Properties for Viscometer 4
        public string txtSampleType4
        {
            get => _viscometerMeasurementModel4.SampleType;
            set
            {
                if (_viscometerMeasurementModel4.SampleType != value)
                {
                    _viscometerMeasurementModel4.SampleType = value;
                    OnPropertyChanged("txtSampleType4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }


        public string txtUserName4
        {
            get => _viscometerMeasurementModel4.UserName;
            set
            {
                if (_viscometerMeasurementModel4.UserName != value)
                {
                    _viscometerMeasurementModel4.UserName = value;
                    OnPropertyChanged("txtUserName4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSampleName4
        {
            get => _viscometerMeasurementModel4.SampleName;
            set
            {
                if (_viscometerMeasurementModel4.SampleName != value)
                {
                    _viscometerMeasurementModel4.SampleName = value;
                    OnPropertyChanged("txtSampleName4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtConcentration4
        {
            get => _viscometerMeasurementModel4.Concentration;
            set
            {
                if (_viscometerMeasurementModel4.Concentration != value)
                {
                    _viscometerMeasurementModel4.Concentration = value;
                    OnPropertyChanged("txtConcentration4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDescription4
        {
            get => _viscometerMeasurementModel4.Description;
            set
            {
                if (_viscometerMeasurementModel4.Description != value)
                {
                    _viscometerMeasurementModel4.Description = value;
                    OnPropertyChanged("txtDescription4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSolventFlowTime4
        {
            get => _viscometerMeasurementModel4.SolventFlowTime;
            set
            {
                if (_viscometerMeasurementModel4.SolventFlowTime != value)
                {
                    _viscometerMeasurementModel4.SolventFlowTime = value;
                    OnPropertyChanged("txtSolventFlowTime4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDryMatter4
        {
            get => _viscometerMeasurementModel4.DryMatter;
            set
            {
                if (_viscometerMeasurementModel4.DryMatter != value)
                {
                    _viscometerMeasurementModel4.DryMatter = value;
                    OnPropertyChanged("txtDryMatter4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtInsoluble4
        {
            get => _viscometerMeasurementModel4.Insoluble;
            set
            {
                if (_viscometerMeasurementModel4.Insoluble != value)
                {
                    _viscometerMeasurementModel4.Insoluble = value;
                    OnPropertyChanged("txtInsoluble4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtSolventVolume4
        {
            get => _viscometerMeasurementModel4.SolventVolume;
            set
            {
                if (_viscometerMeasurementModel4.SolventVolume != value)
                {
                    _viscometerMeasurementModel4.SolventVolume = value;
                    OnPropertyChanged("txtSolventVolume4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtDensity4
        {
            get => _viscometerMeasurementModel4.Density;
            set
            {
                if (_viscometerMeasurementModel4.Density != value)
                {
                    _viscometerMeasurementModel4.Density = value;
                    OnPropertyChanged("txtDensity4");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        public string txtFlowTime4
        {
            get => _viscometerMeasurementModel4.FlowTime;

            set
            {
                if (_viscometerMeasurementModel4.FlowTime != value)
                {
                    Debug.WriteLine("flowTime changed = " + value);
                    _viscometerMeasurementModel4.FlowTime = value;
                    OnPropertyChanged("txtFlowTime4");
                }
            }
        }

        #endregion
        #region Functions
        public ViscometerMeasurementViewModel()
        {
            RS485NMEATCM.Object.PropertyChanged += UpdateFields;
            StartMeasurementButtonCommand1 = new RelayCommand(ExecuteMethodStartMeasurement, CanExecuteMethodStartMeasurement); // Allocate memory to OK button command
            StartMeasurementButtonCommand2 = new RelayCommand(ExecuteMethodStartMeasurement, CanExecuteMethodStartMeasurement); // Allocate memory to OK button command
            StartMeasurementButtonCommand3 = new RelayCommand(ExecuteMethodStartMeasurement, CanExecuteMethodStartMeasurement); // Allocate memory to OK button command
            StartMeasurementButtonCommand4 = new RelayCommand(ExecuteMethodStartMeasurement, CanExecuteMethodStartMeasurement); // Allocate memory to OK button command
            AbortButtonCommand1 = new RelayCommand(ExecuteMethodAbort1, CanExecuteMethodAbort1);
            AbortButtonCommand2 = new RelayCommand(ExecuteMethodAbort2, CanExecuteMethodAbort2);
            //AbortButtonCommand3 = new RelayCommand(AbortExecuteMethod, AbortCanExecuteMethod);
            //AbortButtonCommand4 = new RelayCommand(AbortExecuteMethod, AbortCanExecuteMethod);

            EnableCheckBoxCommand = new RelayCommand(ExecuteMethodEnableCheckBox, CanExecuteMethodEnableCheckBox);

            //Define new time and set its parameters
            this.PropertyChanged += thisPropertyChanged;



            timerStateMachine.Interval = TimeSpan.FromSeconds(1);
            timerStateMachine.Tick += timerStateMachine_Tick;


  

            cleaningTimer1.Interval = TimeSpan.FromSeconds(2000);
            cleaningTimer1.Tick += cleaningTimer1_Tick;

            Debug.WriteLine("Measurement Activated");
            //FirstHalf();
            currentState = "Bath Not Stable";
            previousState = "Initialise";
        }

       

        public void thisPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            Debug.WriteLine("Property Changed = " + e.PropertyName);
        }

        public async void UpdateFields(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            //Debug.WriteLine("Inside Update Field");
            ///Check if the property that generated event is "ReadDataTCM"
            if (e.PropertyName == "ReadDataTCM")
            {
                int length = RS485NMEATCM.ReadDataTCM.Length;
                string packetReceived = RS485NMEATCM.ReadDataTCM.Substring(length-19, 19);
                Debug.WriteLine("Packet Received = " + packetReceived);
                Debug.WriteLine("Raw String = " + RS485NMEATCM.ReadDataTCM);
                if (RS485NMEATCM.ValidateChecksum(packetReceived))
                {

                    if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetBathStatus)
                    {
                        if (packetReceived.Substring(14, 1) == "1" && currentState == "Bath Not Stable")
                        {
                            bathStable = true;
                            Debug.WriteLine("Bath Stabilty Achieved");
                            previousState = currentState;
                            currentState = "Bath Stable";

                        }
                        else
                        {
                            bathStable = false;
                            Debug.WriteLine("Bath Not Stable");
                        }

                    }

                    if (packetReceived.Substring(1, 5) == AddrnComm.MeasurementGetTimer1Command)
                    {
                        currentTimer1 = Convert.ToDouble(packetReceived.Substring(7, 7));
                        Debug.WriteLine("Current Timer Value is = " + currentTimer1);
                        if (currentTimer1 == 0 && currentState != "Pushing Up" & currentState != "Timing")
                        {
                            previousState = currentState;
                            currentState = "Timer Reset";
                        }
                        else if (currentTimer1 != previousTimer1)
                        {
                            previousTimer1 = currentTimer1;
                            if (currentState == "Timing")
                                txtFlowTime1 = Convert.ToString(currentTimer1);
                        }
                        else if (currentTimer1 == previousTimer1 && currentTimer1 != 0)
                        {
                            if (currentState == "Pushing Up")
                            {
                                previousState = currentState;
                                currentState = "Overfill";
                            }

                            else if (currentState == "Timing")
                            {
                                previousState = currentState;
                                currentState = "Timer Stopped";
                                flowTimesCount++;
                                Debug.WriteLine("Flow Time Count = " + flowTimesCount + "Number of Flow Times = " + noOfFlowTimes);
                                

                                if (flowTimesCount <= noOfFlowTimes)
                                {
                                    flowTimes[flowTimesCount - 1] = currentTimer1;
                                    timerStateMachine.Stop();
                                    //Thread.Sleep(Convert.ToInt32(drainTime) * 1000);
                                    Debug.WriteLine("Waiting for Drain Time");
                                    await Task.Delay(Convert.ToInt32(drainTime) * 1000);
                                    Debug.WriteLine("Done waiting for Drain Time");

                                    if(flowTimesCount == 1)
                                    {
                                        currentState = "Bath Not Stable";
                                        previousState = "Initialise";
                                        timerStateMachine.Start();
                                    }
                                    else if(testMode == "determinability" && flowTimesCount > 1)
                                    {
                                        Debug.WriteLine("Test Mode = " + testMode + "  voidRun = " + voidRun);
                                        if ((voidRun == "Yes" && flowTimesCount >= 3) ||
                                            (voidRun == "No" && flowTimesCount >= 2))
                                        {
                                            double det = (flowTimes[flowTimesCount - 1] - flowTimes[flowTimesCount - 2]) * 100 / flowTimes[flowTimesCount - 1];
                                            if (det > 0.05 && flowTimesCount <  noOfFlowTimes)
                                            {
                                                currentState = "Bath Not Stable";
                                                previousState = "Initialise";
                                                timerStateMachine.Start();
                                            }
                                            else
                                            {
                                                timerStateMachine.Stop();
                                                if (CleaningCheckBox1 == true)
                                                {
                                                    CleanThread1 = new Thread(CleanRoutine);
                                                    CleanThread1.Start();
                                                    Debug.WriteLine("Entering Cleaning Mode");
                                                    //CleanRoutine();
                                                }
                                                try
                                                {
                                                    saveToCSVResults();
                                                    flowTimesCount = 0;
                                                }
                                                catch
                                                {

                                                }
                                            }

                                        }
                                        else
                                        {
                                            currentState = "Bath Not Stable";
                                            previousState = "Initialise";
                                            timerStateMachine.Start();
                                        }
                                    }

                                    else if (testMode == "Max-Min" && flowTimesCount > 1)
                                    {
                                        if ((voidRun == "Yes" && flowTimesCount >= 5) ||
                                            (voidRun == "No" && flowTimesCount >= 4))
                                        {
                                            double avg = 0;
                                            for (int i = flowTimesCount -1; i   >   0; i--)
                                            {
                                                avg += flowTimes[i];
                                            }
                                            avg = avg / 4;

                                            int count = 0;
                                            for (int i = flowTimesCount - 1; i > 0; i--)
                                            {
                                                if (Math.Abs(flowTimes[i] - avg) < 0.2)
                                                    count++;
                                            }
                                            if(count != 4 && flowTimesCount < noOfFlowTimes)
                                            {
                                                currentState = "Bath Not Stable";
                                                previousState = "Initialise";
                                                timerStateMachine.Start();
                                            }
                                            else
                                            {
                                                timerStateMachine.Stop();
                                                if (CleaningCheckBox1 == true)
                                                {
                                                    CleanThread1 = new Thread(CleanRoutine);
                                                    CleanThread1.Start();
                                                    Debug.WriteLine("Entering Cleaning Mode");
                                                    //CleanRoutine();
                                                }
                                                try
                                                {
                                                    saveToCSVResults();
                                                    flowTimesCount = 0;
                                                }
                                                catch
                                                {

                                                }

                                            }
                                        }
                                        else
                                        {
                                            currentState = "Bath Not Stable";
                                            previousState = "Initialise";
                                            timerStateMachine.Start();
                                        }
                                    }
                                }
                                else
                                {
                                    flowTimes[flowTimesCount - 1] = currentTimer1;
                                    timerStateMachine.Stop();
                                    if (CleaningCheckBox1 == true)
                                    {
                                        CleanThread1 = new Thread(CleanRoutine);
                                        CleanThread1.Start();
                                        Debug.WriteLine("Entering Cleaning Mode");
                                        //CleanRoutine();
                                    }
                                    try
                                    {
                                        saveToCSVResults();
                                        flowTimesCount = 0;
                                    }
                                    catch
                                    {

                                    }
                                }
                            }
                        }
                    }
                    if (packetReceived.Substring(1, 5) == "GTPC1")
                    {
                        if (packetReceived.Substring(7, 8) == "00000000" && currentState == "Timer Reset")
                        {
                            previousState = currentState;
                            currentState = "Equilibrium";
                        }
                        else if (packetReceived.Substring(7, 8) == "00000000" && currentState == "Overfill")
                        {
                            previousState = currentState;
                            currentState = "Holding";
                        }
                        else if (packetReceived.Substring(7, 8) == "01000000" && currentState == "Timer Reset")
                        {
                            previousState = currentState;
                            currentState = "Release";
                        }
                        else if (packetReceived.Substring(7, 8) == "10100000" && currentState == "Loading")
                        {
                            previousState = currentState;
                            currentState = "Pushing Up";
                        }
                        else if (packetReceived.Substring(7, 8) == "01100000" && currentState == "Equilibrium")
                        {
                            previousState = currentState;
                            currentState = "Loading";
                        }
                        else if (packetReceived.Substring(7, 8) == "01100000" && currentState == "Release")
                        {
                            previousState = currentState;
                            currentState = "Timing";
                        }

                    }
                }
            }
        }

        public void saveToCSVResults()
        {
            double det = Math.Abs((flowTimes[flowTimesCount-1] - flowTimes[flowTimesCount - 2]) * 100 / flowTimes[flowTimesCount -1]);
            double averageFlowTime = 0;
            string flowTimesResults = null;
            if (testMode == "determinability")
            {
                averageFlowTime = (flowTimes[flowTimesCount - 1] + flowTimes[flowTimesCount - 2]) / 2;
                flowTimesResults = "\nFlow Time 1 (s)                              = " + Convert.ToString(flowTimes[flowTimesCount - 2]) +
                                   "\nFlow Time 2 (s)                              = " + Convert.ToString(flowTimes[flowTimesCount - 1]);

            }
            else if (testMode == "Max-Min")
            {
                averageFlowTime = (flowTimes[flowTimesCount - 1] + flowTimes[flowTimesCount - 2] +
                                   flowTimes[flowTimesCount - 3] + flowTimes[flowTimesCount - 4]) / 4;
                flowTimesResults = "\nFlow Time 1 (s)                              = " + Convert.ToString(flowTimes[flowTimesCount - 4]) +
                                   "\nFlow Time 2 (s)                              = " + Convert.ToString(flowTimes[flowTimesCount - 3]) +
                                   "\nFlow Time 3 (s)                              = " + Convert.ToString(flowTimes[flowTimesCount - 2]) +
                                   "\nFlow Time 4 (s)                              = " + Convert.ToString(flowTimes[flowTimesCount - 1]);
            }

            double RV = averageFlowTime / Convert.ToDouble(txtSolventFlowTime1);
            double doubleSolventFlowtime = Convert.ToDouble(txtSolventFlowTime1);
            double correctedSolventViscosity = doubleSolventFlowtime * viscometerConstant - KEFactor / (doubleSolventFlowtime * doubleSolventFlowtime);
            double correctedSolutionViscosity = averageFlowTime * viscometerConstant - KEFactor / (averageFlowTime * averageFlowTime);
            double percentageSolventViscosityChange = KEFactor / (viscometerConstant * (Math.Pow(Convert.ToDouble(txtSolventFlowTime1), 3)));
            double percentageSolutionViscosityChange = KEFactor / (viscometerConstant * Math.Pow(averageFlowTime, 3));
            string solventFlowTimeString = null;
            string solutionFlowTimeString = null;
            string RVDetString = null;
            if(kECorrectioMode == "On")
            {
                solventFlowTimeString = "\nSolvent Flow Time (s)                        = " + txtSolventFlowTime1 +
                                        "\nSolvent Corrected Viscosity (mm^2/s)/s       = " + Convert.ToString(correctedSolventViscosity) +
                                         "\n%Correction in Solvent Viscosity            = " + Convert.ToString(percentageSolventViscosityChange);
                solutionFlowTimeString = "\nAverage Flow Time (s)                        = " + Convert.ToString(averageFlowTime) +
                                         "\nSolution Uncorrected Viscosity, KV (mm^2/s)  = " + Convert.ToString(Math.Round(viscometerConstant * (averageFlowTime), 3)) +
                                         "\nSolution Corrected Viscosity (mm^2/s)/s      = " + Convert.ToString(correctedSolutionViscosity) +
                                         "\n%Correction in Solution Viscosity            = " + Convert.ToString(percentageSolutionViscosityChange);
                RVDetString = "\nRV                                           = " + Convert.ToString(correctedSolutionViscosity / correctedSolventViscosity);
                               
            }
            else if(kECorrectioMode == "Off")
            {
                solventFlowTimeString = "\nSolvent Flow Time (s)                        = " + txtSolventFlowTime1;
                solutionFlowTimeString = "\nAverage Flow Time (s)                        = " + Convert.ToString(averageFlowTime) +
                                         "\nSolution Uncorrected Viscosity, KV (mm^2/s)  = " + Convert.ToString(Math.Round(viscometerConstant * (averageFlowTime), 3));
                RVDetString = "\nRV                                           = " + Convert.ToString(averageFlowTime/doubleSolventFlowtime);
                   
            }
            if(testMode == "determinability")
            {
                RVDetString = RVDetString +
                              "\ndeterminability (%)                          = " + Math.Round(det, 2);
            }

            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(@"C:\Results\Results.txt", true))
            {
                file.WriteLine(
                    "Test Date                                      = " + DateTime.Now.ToString("dd-MM-yyyy") +
                    "\nTest Time                                    = " + DateTime.Now.ToString("hh:mm:ss") +
                    "\nSample Name                                  = " + txtSampleName1 +
                    "\nSample Type                                  = " + txtSampleType1 +
                    "\nConcentration                                = " + txtConcentration1 +
                    "\nDescription                                  = " + txtDescription1 +
                    "\nTest Mode                                    = " + testMode +
                    solventFlowTimeString +
                    "\nUser Name                                    = " + txtUserName1 +
                    "\nViscometer Serial                            = " + txtViscometer1 +
                    "\nViscometer Constant (mm^2/s)/s               = " + Convert.ToString(viscometerConstant) +
                    "\nViscometer Size                              = " + "1B" +
                    "\nViscometer Type                              = " + "UBBELODHE" +
                    "\nE                                            = " + Convert.ToString(KEFactor) +
                    flowTimesResults +
                    solutionFlowTimeString + 
                    RVDetString+
                    "\n\n"

                    );
            }
        }
    
        public void saveResults()
        {
            
        }

        async void timerStateMachine_Tick(object sender, EventArgs e)
        {
            Debug.WriteLine("Inside Timer State Machine Timer");
            Debug.WriteLine("Current State = " + currentState + "  Previous State = " + previousState);
            if((currentState == "Bath Not Stable") && (previousState == "Initialise"))
            {
                SendCommand(bathAddress,"GETSB", "00000000");
            }
            else if ((currentState == "Bath Stable") && (previousState == "Bath Not Stable"))
            {
                SendCommand(positionAddress,"RSTT1", "00000000");
                Thread.Sleep(delayMS); //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GETT1", "00000000");       
            }
            else if((currentState == "Timer Reset") && (previousState == "Bath Stable"))
            {
                SendCommand(positionAddress, "RSTM1", "00000000");

                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"STPC1", AddrnComm.MeasurementHoldOrEquilibriumSampleData);
                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GTPC1", "00000000");

            }
            else if ((currentState == "Equilibrium") && (previousState == "Timer Reset"))
            {
                SendCommand(positionAddress,"STPC1", AddrnComm.MeasurementReleaseOrLoadSampleData);
                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GTPC1", "00000000");
            }
            else if ((currentState == "Loading") && (previousState == "Equilibrium"))
            {
                SendCommand(positionAddress,"STPC1", AddrnComm.MeasurementPushSampleData);
                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GTPC1", "00000000");
            }
            else if ((currentState == "Pushing Up") && (previousState == "Loading"))
            {
                SendCommand(positionAddress,"GETT1", "00000000");
            }
            else if ((currentState == "Overfill") && (previousState == "Pushing Up"))
            {
                timerStateMachine.Stop();
                await Task.Delay(Convert.ToInt32(percentageOverfill * currentTimer1 / 100) * 1000);// Thread.Sleep(delayMS); Thread.Sleep(Convert.ToInt32(percentageOverfill * currentTimer1 / 100) * 1000);
                SendCommand(positionAddress,"STPC1", AddrnComm.MeasurementHoldOrEquilibriumSampleData);
                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GTPC1", "00000000");
                timerStateMachine.Start();
            }
            else if ((currentState == "Holding") && (previousState == "Overfill"))
            {
                SendCommand(positionAddress,"RSTT1", "00000000");
                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GETT1", "00000000");
            }
            else if ((currentState == "Timer Reset") && (previousState == "Holding"))
            {
                SendCommand(positionAddress,"STPC1", AddrnComm.MeasurementSettleSampleData);
                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GTPC1", "00000000");
            }
            else if ((currentState == "Release") && (previousState == "Timer Reset"))
            {
                SendCommand(positionAddress,"STPC1", AddrnComm.MeasurementReleaseOrLoadSampleData);
                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GTPC1", "00000000");
            }
            else if ((currentState == "Timing") && (previousState == "Release"))
            {
                SendCommand(positionAddress,"GETT1", "00000000");
            }
            
            else if ((currentState == "Timer Stopped") && (previousState == "Timing"))
            {
                //timerStateMachine.Stop();
                
                //timerStateMachine.Start();
                SendCommand(positionAddress,"STPC1", AddrnComm.MeasurementHoldOrEquilibriumSampleData);
                Thread.Sleep(delayMS);  //await Task.Delay(delayMS);// Thread.Sleep(delayMS);
                SendCommand(positionAddress,"GTPC1", "00000000");
                //timerStateMachine.Stop();
            }
        }

        public void SendCommand(string address, string command, string data)
        {
            if (!RS485NMEATCM._serialPort.IsOpen)
            {
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(address, command, data);
            }
        }

        public void CleanRoutine()
        {
            Thread.Sleep(200);
            Debug.WriteLine("Inside the CleaneRoutine Mode");
            if (abortState1 == false)
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(measurementAddress, AddrnComm.MeasurementSetDryingLoop1, "15.00000");
            Thread.Sleep(200);
            if (abortState1 == false)
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(measurementAddress, AddrnComm.MeasurementSetSampleExtractionLoop1, MeasurementLoops);
            Thread.Sleep(200);
            if (abortState1 == false)
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(measurementAddress, AddrnComm.MeasurementSetSolventCleanLoop1, MeasurementLoops);
            Thread.Sleep(200);
            if (abortState1 == false)
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(measurementAddress, AddrnComm.MeasurementSetNumberOfCleaningSolvents1, "3.000000");
            Thread.Sleep(200);
            if (abortState1 == false)
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(measurementAddress, AddrnComm.MeasurementSetNumberOfCleaningSolvents1, "3.000000");
            Thread.Sleep(200);

            if (abortState1 == false)
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(measurementAddress, AddrnComm.MeasurementEnableCleanHead1, "00000000");
            cleaningTimer1.Start();
        }

        void cleaningTimer1_Tick(object sender, EventArgs e)
        {
            cleaningTimer1.Stop();
            CleanThread1.Abort();

            if (abortState1 == false)
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(measurementAddress, AddrnComm.MeasurementAbortCleanHead1, "1.000000");

        }
        /// <summary>
        /// This method is executed when OK button is pressed and when CanExecuteMethod returns true
        /// </summary>
        /// <param name="parameter"></param>
        private void ExecuteMethodStartMeasurement(object parameter)
        {
            drainTime = Convert.ToDouble(GlobalParameters.drainTime);
            equilibriumTime = Convert.ToDouble(GlobalParameters.equilibriumTime);
            percentageOverfill = Convert.ToDouble(GlobalParameters.percentageOverfill);
            noOfFlowTimes = Convert.ToInt32(GlobalParameters.maxFlowTimes);
            testMode = GlobalParameters.testMode;
            voidRun = GlobalParameters.voidRun;
            kECorrectioMode = GlobalParameters.kECorrection;
            flowTimes = new double[noOfFlowTimes];

            Debug.WriteLine("Drain Time = " + drainTime + "  Equilibrium Time = " + equilibriumTime + " Test Mode = " + testMode 
                + "   Void Run = " + voidRun + "   KE Correction Mode = " + kECorrectioMode);

            if(testMode == "determinability" && voidRun == "Yes")
            {
                if(noOfFlowTimes < 3)
                {
                    MessageBox.Show("Error: Increase the number of flow times to comply with determinability and void run settings. Minimum flow times needed is 3");
                    return;
                }
                    
            }
            else if(testMode == "determinability" && voidRun == "No")
            {
                if(noOfFlowTimes <2)
                {
                    MessageBox.Show("Error: Increase the number of flow times to comply with determinability settings. Minimum flow times needed is 2");
                    return;
                }
            }

            if (EnableCheckBox1 == true)
            {
                if (SampleLoadedCheckBox1 != true)
                {
                    MessageBox.Show("Sample loaded check is not performed? Please click the check box 'Sample loaded?' in position 1. Please disable position 1 if not required");
                    canAbort1 = false;
                    return;
                }

                else if (StationCappedCheckBox1 != true)
                {
                    MessageBox.Show("Filling station capping check is not performed? Please click the check box 'Filling station capped' in position 1. Please disable position 1 if not required");
                    canAbort1 = false;
                    return;
                }
                else
                {
                    canAbort1 = true;

                 /*   if (MessageBox.Show("Have you filled the viscometer and put the cap on position 1?", "Safety Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                    {
                        //do no stuff
                        return;
                    }
                    else
                    {
                        //do yes stuff
                        if (MessageBox.Show("All viscometers will be locked untill the measurement finishes. Have you used all the required positions?", "Position Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                        {
                            //do no stuff
                            return;

                        }
                        else
                        {
                            //do yes stuff
                            
                            firstHalfThread1 = new Thread(FirstHalf);
                            firstHalfThread1.Start();
                            canAbort1 = true;
                        }


                    }*/

                }
            }

            if (EnableCheckBox2 == true)
            {
                if (SampleLoadedCheckBox2 != true)
                {
                    MessageBox.Show("Sample loaded check is not performed? Please click the check box 'Sample loaded?' in position 2. Please disable position 2 if not required");
                    canAbort2 = false;
                    return;
                }
                else if (StationCappedCheckBox2 != true)
                {
                    MessageBox.Show("Filling station capping check is not performed? Please click the check box 'Filling station capped' in position 2. Please disable position 2 if not required ");
                    canAbort2 = false;
                    return;
                }
                else
                {

                    canAbort2 = true;
                   /* if (MessageBox.Show("Have you filled the viscometer and put the cap on position 2?", "Safety Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                    {
                        //do no stuff
                        return;
                    }
                    else
                    {
                        //do yes stuff
                        if (MessageBox.Show("All viscometers will be locked untill the measurement finishes. Have you used all the required positions?", "Position Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                        {
                            //do no stuff
                            firstHalfThread1 = new Thread(FirstHalf);
                            firstHalfThread1.Start();
                            canAbort2 = true;
                        }
                        else
                        {
                            //do yes stuff
                            return;

                        }


                    }*/

                }
            }
            Debug.WriteLine("canAbort1 = " + Convert.ToString(canAbort1) + " canAbort2 = " + Convert.ToString(canAbort2));
            if(canAbort1 || canAbort2)
            {
                if (MessageBox.Show("All viscometers will be locked untill the measurement finishes. Have you used all the required positions?", "Position Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                {
                    //do no stuff
                    canAbort1 = false;
                    canAbort2 = false;
                    return;
                    
                }
                else
                {
                    //do yes stuff
                    if (canAbort1)
                    {
                        timerStateMachine.Start();
                        //EnableCheckBox1 = false;
                        
                    }
                    if(canAbort2)
                    {
                        //EnableCheckBox2 = false;
                    }
                    

                }

            }


            /*string param = Convert.ToString(parameter);
            address = param.Substring(7, 1);
            unit = param.Substring(12, 1);
            Debug.WriteLine("Received parameter value = " + Convert.ToString(parameter) + " Address = " + address + " Unit = " + unit);

            measurementAddress = Convert.ToString(Convert.ToInt32(AddrnComm.MeasurementAddressOffset) + Convert.ToInt32(address) - 1);
            Debug.WriteLine(measurementAddress);


            if (unit == "1")
            {
                resetTimerCommand = AddrnComm.MeasurementResetTimer1Command;
                getTimerCommand = AddrnComm.MeasurementGetTimer1Command;
                measurementPositionCommand = AddrnComm.MeasurementPosition1Command;
                resetHeadCommand = AddrnComm.MeasurementResetHead1Command;
            }
            if (unit == "2")
            {
                resetTimerCommand = AddrnComm.MeasurementResetTimer2Command;
                getTimerCommand = AddrnComm.MeasurementGetTimer2Command;
                measurementPositionCommand = AddrnComm.MeasurementPosition2Command;
                resetHeadCommand = AddrnComm.MeasurementResetHead2Command;
            }
            //saveResults();
            abortState1 = false;
            canAbort1 = true;

            if (MessageBox.Show("Have you filled the viscometer and put the cap on?", "Safety Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
            {
                //do no stuff
            }
            else
            {
                //do yes stuff
                if (MessageBox.Show("All viscometers will be locked untill the measurement finishes. Have you used all the required positions?", "Position Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                {
                    //do no stuff
                    firstHalfThread1 = new Thread(FirstHalf);
                    firstHalfThread1.Start();
                }
                else
                {
                    //do yes stuff
                    
                }

                
            }
            
            startState1 = false;*/
            
        }

        /// <summary>
        /// This method determines the enabling condition for OK command button
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        private bool CanExecuteMethodStartMeasurement(object parameter)
        {

            if ((!String.IsNullOrEmpty(txtUserName1) && !String.IsNullOrEmpty(txtSampleName1)
                && !String.IsNullOrEmpty(txtDescription1) && !String.IsNullOrEmpty(txtSampleType1) && canStart1 == true
                && !String.IsNullOrEmpty(txtConcentration1) && !String.IsNullOrEmpty(txtSolventFlowTime1)
                && !String.IsNullOrEmpty(txtViscometer1) && EnableCheckBox1 && SampleLoadedCheckBox1 && StationCappedCheckBox1) ||
                (!String.IsNullOrEmpty(txtUserName2) && !String.IsNullOrEmpty(txtSampleName2)
                && !String.IsNullOrEmpty(txtDescription2) && !String.IsNullOrEmpty(txtSampleType2) && canStart2 == true
                && !String.IsNullOrEmpty(txtConcentration2) && !String.IsNullOrEmpty(txtSolventFlowTime2)
                && !String.IsNullOrEmpty(txtViscometer2) && EnableCheckBox2 && SampleLoadedCheckBox2 && StationCappedCheckBox2))
            {
                
                return true;
            }

            else
            {
                
                return false;
            }

        }

        /// <summary>
        /// This method is executed when OK button is pressed and when CanExecuteMethod returns true
        /// </summary>
        /// <param name="parameter"></param>
        private void ExecuteMethodAbort1(object parameter)
        {
            //saveResults();

            abortState1 = true;
            if (firstHalfThread1 != null && firstHalfThread1.IsAlive)
                firstHalfThread1.Abort();
            if (secondHalfThread1 != null && secondHalfThread1.IsAlive)
                secondHalfThread1.Abort();
            Debug.WriteLine("Abort called: Abort State = " + abortState1);

            //while (RS485NMEATCM._serialPort.IsOpen) ;
            lock (LockClass._lockKey)
                RS485NMEATCM.SendData(measurementAddress, measurementPositionCommand, AddrnComm.MeasurementReleaseOrLoadSampleData);
                Thread.Sleep(1000);
                Debug.WriteLine("Aborted");
            //while (RS485NMEATCM._serialPort.IsOpen) ;
            lock (LockClass._lockKey)
                RS485NMEATCM.SendData(measurementAddress, resetHeadCommand, AddrnComm.MeasurementPushSampleData);
                Thread.Sleep(1000);
            if (abortState1 == false)
                lock (LockClass._lockKey)
                    RS485NMEATCM.SendData(measurementAddress, AddrnComm.MeasurementAbortCleanHead1, "1.000000");

            Thread.Sleep(1000);
            canStart1 = true;

        }

        /// <summary>
        /// This method determines the enabling condition for OK command button
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        private bool CanExecuteMethodAbort1(object parameter)
        {
            if (canAbort1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// This method is executed when OK button is pressed and when CanExecuteMethod returns true
        /// </summary>
        /// <param name="parameter"></param>
        private void ExecuteMethodAbort2(object parameter)
        {
            //saveResults();

            abortState2 = true;
            if (firstHalfThread1 != null && firstHalfThread1.IsAlive)
                firstHalfThread1.Abort();
            if (secondHalfThread1 != null && secondHalfThread1.IsAlive)
                secondHalfThread1.Abort();
            Debug.WriteLine("Abort called: Abort State = " + abortState1);
            //while (RS485NMEATCM._serialPort.IsOpen) ;
            lock (LockClass._lockKey)
                RS485NMEATCM.SendData(measurementAddress, resetHeadCommand, AddrnComm.MeasurementPushSampleData);
            canStart1 = true;

        }

        /// <summary>
        /// This method determines the enabling condition for OK command button
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        private bool CanExecuteMethodAbort2(object parameter)
        {
            if (canAbort2)
                return true;
            else
                return false;
        }

        private void ExecuteMethodEnableCheckBox(object parameter)
        {
            //saveResults();
            /*if (readyToLoad == true)
                ReadyToLoad = !readyToLoad;
            else 
                ReadyToLoad = readyToLoad;*/
            //ReadyToLoad = !ReadyToLoad;
            //Debug.WriteLine("Ready to Load value is = " + Convert.ToString(ReadyToLoad));

            string param = Convert.ToString(parameter);
            address = param.Substring(7, 1);
            unit = param.Substring(12, 1);
            Debug.WriteLine("Received parameter value = " + Convert.ToString(parameter) + " Address = " + address + " Unit = " + unit);

            measurementAddress = Convert.ToString(Convert.ToInt32(AddrnComm.MeasurementAddressOffset) + Convert.ToInt32(address) - 1);
            Debug.WriteLine(measurementAddress);

            Debug.WriteLine("Enable Check Box Value = " + Convert.ToString(EnableCheckBox1));
            if(!EnableCheckBox1)
            {
                txtSampleType1 = "";
                txtUserName1 = "";
                txtSampleName1 = "";
                txtDescription1 = "";
                txtConcentration1 = "";
                txtSolventFlowTime1 = "";
                txtViscometer1 = "";
                txtDryMatter1 = "";
                txtInsoluble1 = "";
                txtSolventVolume1 = "";
                txtDensity1 = "";
                txtFlowTime1 = "";
                StationCappedCheckBox1 = false;
                SampleLoadedCheckBox1 = false;
            }
            if(EnableCheckBox1)
            {
                if (unit == "1")
                {
                    resetTimerCommand = AddrnComm.MeasurementResetTimer1Command;
                    getTimerCommand = AddrnComm.MeasurementGetTimer1Command;
                    measurementPositionCommand = AddrnComm.MeasurementPosition1Command;
                    resetHeadCommand = AddrnComm.MeasurementResetHead1Command;
                }
                if (unit == "2")
                {
                    resetTimerCommand = AddrnComm.MeasurementResetTimer2Command;
                    getTimerCommand = AddrnComm.MeasurementGetTimer2Command;
                    measurementPositionCommand = AddrnComm.MeasurementPosition2Command;
                    resetHeadCommand = AddrnComm.MeasurementResetHead2Command;
                }
            }

        }

        /// <summary>
        /// This method determines the enabling condition for OK command button
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        private bool CanExecuteMethodEnableCheckBox(object parameter)
        {
            return true;
        }

        #endregion
    }

}