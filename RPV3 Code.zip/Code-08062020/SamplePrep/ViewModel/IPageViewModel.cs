﻿namespace SamplePrep.ViewModel
{
    internal interface IPageViewModel
    {
    }
}