﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SamplePrep.Resources;
using SamplePrep.Model;
using System.Windows.Threading;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Diagnostics;
using System.Globalization;
using LiveCharts;
using LiveCharts.Wpf;
using System.Windows.Media;
using System.Web;

namespace SamplePrep.ViewModel
{
    class ReferenceTemperatureViewModel : ObservableObject
    {
        #region Define objects of ReferenceTemperature Model and RS485NMEATCM class
        
        // Object of the Reference Temperature Model Class
        ReferenceTemperatureModel _referenceTemperatureModel = new ReferenceTemperatureModel();
        //Object of the RS485 class
        //RS485NMEATCM RS485NMEATCM = new RS485NMEATCM();
        //Object of Relay command to execute on OK button press
        public RelayCommand OKButtonCommand { get; set; }
        //Object of Address class for the addressing of temperature control bath
        public AddressingAndCommands AddrnComm = new AddressingAndCommands();
        //1 ms timer to wait before sending next commands
        public DispatcherTimer timer = new DispatcherTimer();

        public DispatcherTimer graphTimer = new DispatcherTimer();
        
        //This field stores the status of PleaseWait indicator. Flase means no indicator
        private bool _pleaseWait = false;
        //Keeps track of the time for which BusyIndicator in View is appearing. 
        //This is useful when offset fails to change through the command. 
        public int _timeOutForPleaseWait = 0;
        //Splash Screen
        SplashScreen splashScreen1  = new SplashScreen("../Images/psl.jpg");
        SplashScreen splashScreen2 = new SplashScreen("../Images/SPS.jpg");

        //Chart related variables
        public SeriesCollection SeriesCollection { get; set; }
        public string[] Labels { get; set; }
        public Func<double, string> YFormatter { get; set; }
        SolidColorBrush StrokeBrush = new SolidColorBrush(Color.FromRgb(83,130,172));
        SolidColorBrush FillBrush = new SolidColorBrush(Color.FromRgb(255, 255, 255));
        SolidColorBrush StrokeBrushControl = new SolidColorBrush(Color.FromRgb(255, 0, 0));
        public int delayMS = 200;
        public int state = 0;






        #endregion

        #region Public fields to hold values of View variables

        /// <summary>
        /// Property to hold background fill colour of Status field
        /// </summary>
        public string StatusBackgroundColour
        {
            get
            {
                //MessageBox.Show(_referenceTemperatureModel.Status);
                if (_referenceTemperatureModel.Status == "Stable")
                    return "#5382ac";
                if (_referenceTemperatureModel.Status == "Unstable")
                    return "Red";
                return "White";
            }
            set
            {
                if (StatusBackgroundColour != value)
                {
                    StatusBackgroundColour = value;
                    OnPropertyChanged("StatusBackgroundColour");

                }
            }
        }

        /// <summary>
        /// Property to hold text colour of Status field
        /// </summary>
        public string StatusForegroundColour
        {
            get
            {
                //MessageBox.Show(_referenceTemperatureModel.Status);
                if (_referenceTemperatureModel.Status == "Stable")
                    return "White";
                if (_referenceTemperatureModel.Status == "Unstable")
                    return "White";
                return "#5382ac";
            }
            set
            {
                if (StatusForegroundColour != value)
                {
                    StatusForegroundColour = value;
                    OnPropertyChanged("ReferenceForegroundColour");

                }
            }
        }

        /// <summary>
        /// This property is used by View to enable and disable busy indicator
        /// </summary>
        public bool PleaseWait
        {
            get => _pleaseWait;
            set
            {
                if (_pleaseWait != value)
                {
                    _pleaseWait = value;
                    OnPropertyChanged("PleaseWait");
                    
                }
            }
        }

        /// <summary>
        /// Public field to hold BathNumbers shown in View
        /// </summary>
        public string BathNumber
        {
            get => _referenceTemperatureModel.BathNumber;
            set
            {
                if(_referenceTemperatureModel.BathNumber != value)
                {
                    _referenceTemperatureModel.BathNumber = value;
                    OnPropertyChanged("BathNumber");
                    //MessageBox.Show("Bath Number= " + BathNumber);
                }
            }
        }

        /// <summary>
        /// Public field to hold current set point value for View
        /// </summary>
        public string txtSetpoint
        {

            get => Math.Round((_referenceTemperatureModel.Setpoint),2).ToString("0.00");
            set
            {
                if(Convert.ToString(_referenceTemperatureModel.Setpoint) !=value )
                {
                    _referenceTemperatureModel.Setpoint = Convert.ToDouble((value));
                    OnPropertyChanged("txtSetpoint");
                    
                }
            }
        }


        /// <summary>
        /// Public field to hold  current reference value for View
        /// </summary>
        public string txtReference
        {
            get => (_referenceTemperatureModel.Reference);
            set
            {
                if(_referenceTemperatureModel.Reference != value)
                {
                    if (Regex.IsMatch(value, @"^[-+]?[.0-9][0-9]+$|^[+-]?[0-9]*[.]{0,1}[0-9]*$"))
                    {
                        _referenceTemperatureModel.Reference = (value);
                        OnPropertyChanged("txtReference");
                    }
                }
            }
        }

        /// <summary>
        /// Public field to hold current bath status in View
        /// </summary>
        public string txtStatus
        {
            get => _referenceTemperatureModel.Status;
            set
            {
                if(_referenceTemperatureModel.Status != value)
                {
                    _referenceTemperatureModel.Status = value;
                    OnPropertyChanged("txtStatus");
                }
            }
        }

        /// <summary>
        /// Public field to hold offset value in View
        /// </summary>
        public string txtOffset
        {
            get => Math.Round((_referenceTemperatureModel.Offset),3).ToString("0.000");
            set
            {
                if(_referenceTemperatureModel.Offset != Convert.ToDouble(value))
                {
                    _referenceTemperatureModel.Offset = Convert.ToDouble(value);
                    OnPropertyChanged("txtOffset");
                }
            }
        }

        /// <summary>
        /// Public field to hold current actual value in View
        /// </summary>
        public string txtActual
        {
            get => Math.Round((_referenceTemperatureModel.Actual),3).ToString("0.000");
            set
            {
                if (Convert.ToString(_referenceTemperatureModel.Actual) != value)
                {
                    
                    _referenceTemperatureModel.Actual = Convert.ToDouble(value);
                    OnPropertyChanged("txtActual");
                }

            }
        }
        #endregion

        #region Functions of ViewModel
        /// <summary>
        /// Constructor of ViewModel
        /// </summary>
        public ReferenceTemperatureViewModel()
        {

            RS485NMEATCM.Object.PropertyChanged += UpdateFields;   //Subscribe to UpdateFields method on the property change of RS485 object
            this.PropertyChanged += OffsetChanged;      //Subscribe to offset change event
            BathNumber = "1";                           // Default bath selected is 1
            OKButtonCommand = new RelayCommand(ExecuteMethod, CanExecuteMethod); // Allocate memory to OK button command

            //Define new time and set its parameters
            
            timer.Interval = TimeSpan.FromSeconds(1.25);
            timer.Tick += timer_Tick;
            timer.Start();

            graphTimer.Interval = TimeSpan.FromSeconds(1.5);
            graphTimer.Tick += graphTimer_Tick;
            graphTimer.Start();

            //splashScreen1.Show(true,true);       

            //splashScreen1.Close(TimeSpan.FromSeconds(5));
            // Thread.Sleep(5000);
            //splashScreen2.Show(true);

            //splashScreen2.Close(TimeSpan.FromSeconds(10));
            // Thread.Sleep(5000);
            InitialiseChart();

        }

        void InitialiseChart()
        {
            SeriesCollection = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Actual Temperature",
                    Values = new ChartValues<double> {},
                    LineSmoothness = 0,
                    Stroke =  StrokeBrush,
                    Fill = System.Windows.Media.Brushes.Transparent,
                    PointGeometry = DefaultGeometries.Circle,
                    PointGeometrySize = 5
                    
                    
            //0: straight lines, 1: really smooth lines
            //PointGeometry = new PointGeometry("m 25 70.36218 20 -28 -20 22 -8 -6 z"),
            //PointGeometrySize = 50,
            //PointForeround = new SolidColorBrush(Windows.UI.Colors.Gray)
                },
                new LineSeries
                {
                    Title = " ",
                    Values = new ChartValues<double> {},
                    LineSmoothness = 0,
                    Stroke = StrokeBrushControl,
                    Fill = System.Windows.Media.Brushes.Transparent,
                    PointGeometry = DefaultGeometries.None
                },
                new LineSeries
                {
                    Title = " ",
                    Values = new ChartValues<double> {},
                    LineSmoothness = 0,
                    Stroke = StrokeBrushControl,
                    Fill = System.Windows.Media.Brushes.Transparent,
                    PointGeometry = DefaultGeometries.None
                },
              /*  new LineSeries
                {
                    Title = "Series 2",
                    Values = new ChartValues<double> { 6, 7, 3, 4 ,6 },
                    PointGeometry = null
                },
                new LineSeries
                {
                    Title = "Series 3",
                    Values = new ChartValues<double> { 4,2,7,2,7 },
                    PointGeometry = DefaultGeometries.Square,
                    PointGeometrySize = 15
                }*/
            };

            Labels = new[] { "Jan", "Feb", "Mar", "Apr", "May" };
            YFormatter = value => value.ToString();

            //modifying the series collection will animate and update the chart
            /*SeriesCollection.Add(new LineSeries
            {
                Title = "Series 4",
                Values = new ChartValues<double> { 5, 3, 2, 4 },
                LineSmoothness = 0, //0: straight lines, 1: really smooth lines
                PointGeometry = new PointGeometry("m 25 70.36218 20 -28 -20 22 -8 -6 z"),
                PointGeometrySize = 50,
                PointForeround = new SolidColorBrush(Windows.UI.Colors.Gray)
            });*/

            //modifying any series values will also animate and update the chart
            //SeriesCollection[3].Values.Add(5d);   
        }


        /// <summary>
        /// Actions to be taken when Offset changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        public void OffsetChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {

            ///Check if the property that generated event is "txtOffset"
            if (e.PropertyName == "txtOffset")
            {
                if (!String.IsNullOrEmpty(txtReference))
                {

                    PleaseWait = false;
                    _timeOutForPleaseWait = 0;
                    MessageBox.Show("Reference changed successfully");
                    txtReference = String.Empty;

                }
            }
        }

        /// <summary>
        /// Function to be called every time data is received through serial port and saved in
        /// ReadDataTCM function. In other words, every time ReadDataTCM variable changes, this function
        /// will be called because it has subscribed to OnPropertyChanged event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void UpdateFields(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            Debug.WriteLine("Inside Update Field");
            ///Check if the property that generated event is "ReadDataTCM"
            if (e.PropertyName == "ReadDataTCM")
            {
                string packetReceived = RS485NMEATCM.ReadDataTCM.Substring(1,19);
                if (RS485NMEATCM.ValidateChecksum(packetReceived))
                {
                    

                    if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetSetPoint)
                    {
                        txtSetpoint = (packetReceived.Substring(7, 7));
                        Debug.WriteLine("Set point value is  " + txtSetpoint);
                    }
                    else if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetBathTemperature)
                    {
                        txtActual = Convert.ToString(packetReceived.Substring(7, 7));
                        

                        
                    }
                    else if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetBathStatus)
                    {
                        if (packetReceived.Substring(14, 1) == "1")
                        {
                            txtStatus = "Stable";
                            Debug.WriteLine("Text variable status = {0}", _referenceTemperatureModel.Status);
                        }
                        else
                        {
                            txtStatus = "Unstable";
                            Debug.WriteLine("Text variable status = {0}", _referenceTemperatureModel.Status);
                        }
                        OnPropertyChanged("StatusBackgroundColour");
                        OnPropertyChanged("StatusForegroundColour");

                    }
                    else if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetBathOffset)
                    {
                        txtOffset = Convert.ToString(packetReceived.Substring(7, 7));
                    }
                    else
                    {

                    }
                }
                else
                    Debug.WriteLine("CheckSum Invalid");
            }
        }

        /// <summary>
        /// This function sends commands on serial port to poll for bath parameters
        /// This function is called by a separate thread
        /// </summary>
        public  void  Transmit()
        {
            string _address = null;            
            int _bathNumberInt = Convert.ToInt16(BathNumber) + Convert.ToInt16(AddrnComm.EVSTCMAddress1);

            if (BathNumber == null)
                _address = AddrnComm.EVSTCMAddress1;
            else
                _address = Convert.ToString(_bathNumberInt - 1);


            Debug.WriteLine("Address is = " + _address);

            //_address = "128";
            if (!RS485NMEATCM._serialPort.IsOpen)
            {
                if (state == 0)
                {
                    lock (LockClass._lockKey)
                    {
                        RS485NMEATCM.SendData(_address, AddrnComm.EVSTCMGetSetPoint, "+040.000");
                    }

                }

                else if (state == 1)
                {
                    lock (LockClass._lockKey)
                    {
                        RS485NMEATCM.SendData(_address, AddrnComm.EVSTCMGetBathOffset, "+040.000");
                    }
                }

                else if (state == 2)
                {
                    lock (LockClass._lockKey)
                    {
                        RS485NMEATCM.SendData(_address, AddrnComm.EVSTCMGetBathTemperature, "+040.000");
                    }

                }
                else if (state == 3)
                {
                    lock (LockClass._lockKey)
                    {
                        RS485NMEATCM.SendData(_address, AddrnComm.EVSTCMGetBathStatus, "+040.000");
                    }
                }
                state++;
                if (state > 3)
                    state = 0;
            }

        }
        /// <summary>
        /// Time function to be called continuously to update View
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void timer_Tick(object sender, EventArgs e)
        {
            //Create a new thread ot Transmit() function and start it
            Thread t = new Thread(Transmit);
            t.Start();
            Debug.WriteLine("Inside Check Temperature");
            //This snipped sets busy indicator to flase through PleaseWait property
            //after 15 seconds
            if (PleaseWait == true)
            {
                _timeOutForPleaseWait++;
                if (_timeOutForPleaseWait > 3)
                {
                    PleaseWait = false;
                    _timeOutForPleaseWait = 0;
                    MessageBox.Show("Offset remains unchanged");
                    
                }
            }
        }

        /// <summary>
        /// Time function to be called continuously to update View
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void graphTimer_Tick(object sender, EventArgs e)
        {
            //Create a new thread ot Transmit() function and start it
            double setPointDouble = Convert.ToDouble(txtSetpoint);
            double controlLower = setPointDouble - 0.05;
            double controlHigher = setPointDouble + 0.05;
            
            if (Convert.ToDouble(txtActual) != 0)
            {
                SeriesCollection[0].Values.Add(Convert.ToDouble(txtActual));
                //SeriesCollection[0].ScalesXAt = 40;
                SeriesCollection[1].Values.Add(controlLower);
                SeriesCollection[2].Values.Add(controlHigher);
                if (SeriesCollection[0].Values.Count > 180 || GlobalParameters.clearTemperatureFlag)
                {
                    SeriesCollection[0].Values.Clear();
                    SeriesCollection[1].Values.Clear();
                    SeriesCollection[2].Values.Clear();
                    if (GlobalParameters.clearTemperatureFlag)
                        GlobalParameters.clearTemperatureFlag = false;
                    Debug.WriteLine("Series Collection Cleared");
                }
            }
        }

        /// <summary>
        /// This method is executed when OK button is pressed and when CanExecuteMethod returns true
        /// </summary>
        /// <param name="parameter"></param>
        private void ExecuteMethod(object parameter)
        {
            
            //Check is Reference field is not null or Empty
            if (!String.IsNullOrEmpty(txtReference))
            {
                string _address = null;
                int _bathNumberInt = Convert.ToInt16(BathNumber) + Convert.ToInt16(AddrnComm.EVSTCMAddress1);

                if (BathNumber == null)
                    _address = AddrnComm.EVSTCMAddress1;
                else
                    _address = Convert.ToString(_bathNumberInt - 1);
                //Reference and Actual shall not exceed by 0.3 degrees C or F
                if (Math.Abs(Convert.ToDouble(txtReference) - Convert.ToDouble(txtActual)) > AddrnComm.ReferenceAndActualOffset)
                {
                    
                    string messageBoxText = "Reference and actual temperature difference is outside the safe range. Do you want to proceed ? ";
                    string caption = "Reference Temperature Setting Warning";
                    MessageBoxButton button = MessageBoxButton.YesNo;
                    MessageBoxImage icon = MessageBoxImage.Warning;
                    if (MessageBox.Show(messageBoxText, caption, button, icon) == MessageBoxResult.Yes)
                    {
                        string str = String.Format("{0:.0000}", txtReference);
                        //while (RS485NMEATCM._serialPort.IsOpen) ;
                        lock(LockClass._lockKey) // Will wait for x lock to be free
                            RS485NMEATCM.SendData(_address, AddrnComm.EVSTCMSetBathReference, txtReference);
                        Debug.WriteLine("Command Executed \n");
                        //txtReference = String.Empty;
                    }
                }
                else
                {
                    //while (RS485NMEATCM._serialPort.IsOpen) ;
                    lock (LockClass._lockKey)
                        RS485NMEATCM.SendData(_address, AddrnComm.EVSTCMSetBathReference, txtReference);
                    Debug.WriteLine("Command Executed \n");
                    //txtReference = String.Empty;
                    

                };

                //Wait for txtOffset command to finish
                PleaseWait = true;
                

            }
            //timer.Start();
        }

        /// <summary>
        /// This method determines the enabling condition for OK command button
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        private bool  CanExecuteMethod(object parameter)
        {
            if (!String.IsNullOrEmpty(txtReference))
                return true;
            else
                return false;
        }

        #endregion
    }
}
