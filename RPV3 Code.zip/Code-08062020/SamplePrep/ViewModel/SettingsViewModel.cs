﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SamplePrep.Resources;
using SamplePrep.Model;
using System.Windows.Threading;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Diagnostics;
using System.Globalization;

namespace SamplePrep.ViewModel
{
    class SettingsViewModel : ObservableObject
    {
        #region Define objects of Settings Model and RS485NMEATCM class
        /// <summary>
        /// Object of the Reference Settings Model Class
        /// </summary>
        SettingsModel _settingsModel = new SettingsModel();
        //RS485NMEATCM RS485NMEATCM = new RS485NMEATCM();
        public RelayCommand OKButtonCommand { get; set; }
        public RelayCommand ClearOffsetButtonCommand { get; set; }
        public AddressingAndCommands AddrnComm = new AddressingAndCommands();
        string _address = null;
        int _bathNumberInt = 0;
        public string message = null;
        public string currentCoolingMode = null;
        public string unitsWithBracket = null;
        public int state = 0;
        #endregion

        #region Public fields to hold values of View variables


        /// <summary>
        /// Public field to hold BathNumbers shown in View
        /// </summary>
        public string txtBathNumber
        {
            get => _settingsModel.BathNumber;
            set
            {
                if (_settingsModel.BathNumber != value)
                {
                    _settingsModel.BathNumber = value;
                    OnPropertyChanged("BathNumber");
                    
                }
            }
        }

        /// <summary>
        /// Public field to hold current set point value for View
        /// </summary>
        public string txtSetpoint
        {
            get => _settingsModel.Setpoint;
            set
            {
                if (Convert.ToString(_settingsModel.Setpoint) != value)
                {
                    if (Regex.IsMatch(value, @"^[-+]?[.0-9][0-9]+$|^[+-]?[0-9]*[.]{0,1}[0-9]*$"))
                    {
                        _settingsModel.Setpoint = value;
                        OnPropertyChanged("txtSetpoint");
                        Debug.WriteLine(txtSetpoint + "00");
                    }
                }
            }
        }

        /// <summary>
        /// Public field to hold current set point value for View
        /// </summary>
        public string txtCurrentSetpoint
        {
            get => (_settingsModel.CurrentSetpoint).ToString("0.000");
            set
            {
                if (Convert.ToString(_settingsModel.CurrentSetpoint) != value)
                {
                    if (Regex.IsMatch(value, @"^[-+]?[.0-9][0-9]+$|^[+-]?[0-9]*[.]{0,1}[0-9]*$"))
                    {
                        _settingsModel.CurrentSetpoint = Convert.ToDouble((value));
                        OnPropertyChanged("txtCurrentSetpoint");
                        Debug.WriteLine(txtSetpoint + "00");
                    }
                }
            }
        }

        /// <summary>
        /// Public field to hold current set point value for View
        /// </summary>
        public string txtCurrentOffset
        {
            get => (_settingsModel.CurrentOffset).ToString("0.000");
            set
            {
                if (Convert.ToString(_settingsModel.CurrentOffset) != value)
                {
                    if (Regex.IsMatch(value, @"^[-+]?[.0-9][0-9]+$|^[+-]?[0-9]*[.]{0,1}[0-9]*$"))
                    {
                        _settingsModel.CurrentOffset = Convert.ToDouble((value));
                        OnPropertyChanged("txtCurrentOffset");
                        
                    }
                }
            }
        }

        /// <summary>
        /// Public field to hold  current reference value for View
        /// </summary>
        public string txtCoolingMode
        {
            get => (_settingsModel.CoolingMode);
            set
            {
                if ((_settingsModel.CoolingMode) != value)
                {
                    _settingsModel.CoolingMode = (value);
                    OnPropertyChanged("txtCoolingMode");
                }
            }
        }

        /// <summary>
        /// Public field to hold current bath status in View
        /// </summary>
        public string txtUnits
        {
            get => _settingsModel.Units;
            set
            {
                if (_settingsModel.Units != value)
                {
                    _settingsModel.Units = value;
                    OnPropertyChanged("txtUnits");
                    
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string txtKECorrection
        {
            get => _settingsModel.KECorrection;
            set
            {
                if (_settingsModel.KECorrection != value)
                {
                    _settingsModel.KECorrection = value;
                    OnPropertyChanged("KECorrection");
                    GlobalParameters.kECorrection = value;

                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string txtMaxFlowTimes
        {
            get => _settingsModel.MaxFlowTimes;
            set
            {
                if (_settingsModel.MaxFlowTimes != value)
                {
                    _settingsModel.MaxFlowTimes = value;
                    OnPropertyChanged("MaxFlowTimes");
                    GlobalParameters.maxFlowTimes = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string txtTestMode
        {
            get => _settingsModel.TestMode;
            set
            {
                if (_settingsModel.TestMode != value)
                {
                    _settingsModel.TestMode = value;
                    OnPropertyChanged("TestMode");
                    GlobalParameters.testMode = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string txtDrainTime
        {
            get => _settingsModel.DrainTime;
            set
            {
                if (_settingsModel.DrainTime != value)
                {
                    _settingsModel.DrainTime = value;
                    OnPropertyChanged("DrainTime");
                    GlobalParameters.drainTime = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string txtEquilibriumTime
        {
            get => _settingsModel.EquilibriumTime;
            set
            {
                if (_settingsModel.EquilibriumTime != value)
                {
                    _settingsModel.EquilibriumTime = value;
                    OnPropertyChanged("EquilibriumTime");
                    GlobalParameters.equilibriumTime = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string txtPercentageOverfill
        {
            get => _settingsModel.PercentageOverfill;
            set
            {
                if (_settingsModel.PercentageOverfill != value)
                {
                    _settingsModel.PercentageOverfill = value;
                    OnPropertyChanged("PercentageOverfill");
                    GlobalParameters.percentageOverfill = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string txtVoidRun
        {
            get => _settingsModel.VoidRun;
            set
            {
                if (_settingsModel.VoidRun != value)
                {
                    _settingsModel.VoidRun = value;
                    OnPropertyChanged("VoidRun");
                    GlobalParameters.voidRun = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string DryingTimeCycles
        {
            get => _settingsModel.DryingTimeCycles;
            set
            {
                if (_settingsModel.DryingTimeCycles != value)
                {
                    _settingsModel.DryingTimeCycles = value;
                    OnPropertyChanged("DryingTimeCycles");
                    Debug.WriteLine("DryingTimeCycles = " + DryingTimeCycles);
                    _settingsModel.DryingTimeSeconds = Convert.ToString(Convert.ToInt32(DryingTimeCycles) * 20) + " s";
                    OnPropertyChanged("DryingTimeSeconds");
                    //GlobalParameters.voidRun = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string DryingTimeSeconds
        {
            get => _settingsModel.DryingTimeSeconds;
            set
            {
                if (_settingsModel.DryingTimeSeconds != value)
                {

                    _settingsModel.DryingTimeSeconds = Convert.ToString(Convert.ToInt32(DryingTimeCycles) * 20);
                    Debug.WriteLine("DryingTimeSeconds = " + DryingTimeSeconds);
                    OnPropertyChanged("DryingTimeSeconds");
                    //GlobalParameters.voidRun = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string ExtractionTimeCycles
        {
            get => _settingsModel.ExtractionTimeCycles;
            set
            {
                if (_settingsModel.ExtractionTimeCycles != value)
                {
                    _settingsModel.ExtractionTimeCycles = value;
                    OnPropertyChanged("ExtractionTimeCycles");
                    Debug.WriteLine("ExtractionTimeCycles = " + ExtractionTimeCycles);
                    _settingsModel.ExtractionTimeSeconds = Convert.ToString(Convert.ToInt32(ExtractionTimeCycles) * 20) + " s";
                    OnPropertyChanged("ExtractionTimeSeconds");
                    //GlobalParameters.voidRun = value;
                    Debug.WriteLine("Extraction Time Seconds = " + ExtractionTimeSeconds);
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string ExtractionTimeSeconds
        {
            get => _settingsModel.ExtractionTimeSeconds;
            set
            {
                if (_settingsModel.ExtractionTimeSeconds != value)
                {

                    _settingsModel.ExtractionTimeSeconds = Convert.ToString(Convert.ToInt32(ExtractionTimeSeconds) * 20);
                    Debug.WriteLine("DryingTimeSeconds = " + ExtractionTimeSeconds);
                    OnPropertyChanged("ExtractionTimeSeconds");
                    //GlobalParameters.voidRun = value;
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string SolventTimeCycles
        {
            get => _settingsModel.SolventTimeCycles;
            set
            {
                if (_settingsModel.SolventTimeCycles != value)
                {

                    _settingsModel.SolventTimeCycles = value;
                    Debug.WriteLine("Solvent Time Cycles = " + SolventTimeCycles);
                    OnPropertyChanged("SolventTimeCycles");
                    //GlobalParameters.voidRun = value;
                    _settingsModel.SolventTimeSeconds = Convert.ToString(Convert.ToInt32(SolventTimeCycles) * 20) + "s";
                    OnPropertyChanged("SolventTimeSeconds");
                }
            }
        }

        /// <summary>
        /// Reference temperature public property
        /// </summary>
        public string SolventTimeSeconds
        {
            get => _settingsModel.SolventTimeSeconds;
            set
            {
                if (_settingsModel.SolventTimeSeconds != value)
                {

                    _settingsModel.SolventTimeSeconds = Convert.ToString(Convert.ToInt32(SolventTimeSeconds) * 20);
                    Debug.WriteLine("Solvent Time Seconds = " + SolventTimeSeconds);
                    OnPropertyChanged("SolventTimeSeconds");
                    //GlobalParameters.voidRun = value;
                }
            }
        }

        #endregion

        #region Functions of ViewModel
        /// <summary>
        /// Constructor of ViewModel
        /// </summary>
        public SettingsViewModel()
        {

            RS485NMEATCM.Object.PropertyChanged += UpdateFields;
            OKButtonCommand = new RelayCommand(ExecuteMethod, CanExecuteMethod);
            ClearOffsetButtonCommand = new RelayCommand(ClearOffsetExecuteMethod, ClearOffsetCanExecuteMethod);

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(20);
            timer.Tick += timer_Tick;
            timer.Start();

            setDefaults();
            
        }


        public void setDefaults()
        {
            txtCoolingMode = "Off";
            txtUnits = "°C";
            txtVoidRun = "No";
            txtTestMode = "determinability";
            txtDrainTime = "25";
            txtEquilibriumTime = "3";
            txtKECorrection = "On";
            txtMaxFlowTimes = "2";
            txtPercentageOverfill = "10";
            txtBathNumber = "1";
            

            
        }

        /// <summary>
        /// Function to be called every time data is received through serial port and saved in
        /// ReadDataTCM function. In other words, every time ReadDataTCM variable changes, this function
        /// will be called because it has subscribed to OnPropertyChanged event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void UpdateFields(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {

            ///Check if the property that generated event is "ReadDataTCM"
            if (e.PropertyName == "ReadDataTCM")
            {
                string packetReceived = RS485NMEATCM.ReadDataTCM.Substring(1, 19);
                if (RS485NMEATCM.ValidateChecksum(packetReceived))
                {
                    if (RS485NMEATCM.ValidateChecksum(packetReceived))
                    {

                        if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMSetChillerMode)
                        {
                            //txtSetpoint = (packetReceived.Substring(7, 7));
                            if (packetReceived.Substring(10, 1) == "1")
                            {
                                Debug.WriteLine("Received Chiller Mode is" + packetReceived.Substring(1, 5));
                                currentCoolingMode = "On";
                            }
                            else
                                currentCoolingMode = "Off";
                        }
                        else if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetSetPoint)
                        {
                            string degreeCTemperature = Convert.ToString(packetReceived.Substring(7, 7));
                            //string degreeCTemperature = "35";
                               
                            if (txtUnits == "°F")
                                txtCurrentSetpoint = Convert.ToString(Convert.ToDouble(degreeCTemperature)*9/5 + 32);
                            else
                                txtCurrentSetpoint = degreeCTemperature;


                        }
                        else if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetBathOffset)
                        {
                            string degreeCTemperature = Convert.ToString(packetReceived.Substring(7, 7));

                            txtCurrentOffset = degreeCTemperature;
                        }
                        /*else if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetBathStatus)
                        {
                            if (packetReceived.Substring(14, 1) == "1")
                            {
                                txtStatus = "Stable";
                                Debug.WriteLine("Text variable status = {0}", _referenceTemperatureModel.Status);
                            }
                            else
                            {
                                txtStatus = "Unstable";
                                Debug.WriteLine("Text variable status = {0}", _referenceTemperatureModel.Status);
                            }
                            OnPropertyChanged("StatusBackgroundColour");
                            OnPropertyChanged("StatusForegroundColour");

                        }
                        else if (packetReceived.Substring(1, 5) == AddrnComm.EVSTCMGetBathOffset)
                        {
                            txtOffset = Convert.ToString(packetReceived.Substring(7, 7));
                        }
                        else
                        {

                        }*/
                    }
                }
            }
        }

        public void Transmit()
        {
            _address = null;
            int _bathNumberInt = Convert.ToInt16(txtBathNumber) + Convert.ToInt16(AddrnComm.EVSTCMAddress1);

            if (txtBathNumber == null)
                _address = AddrnComm.EVSTCMAddress1;
            else
                _address = Convert.ToString(_bathNumberInt - 1);

            if (!RS485NMEATCM._serialPort.IsOpen)
            {
                if (state == 0)
                {
                    lock (LockClass._lockKey)
                    {
                        RS485NMEATCM.SendData(_address, "GETSB", "+040.000");
                    }
                    state++;
                }
                else if (state == 1)
                {
                    lock (LockClass._lockKey)
                    {
                        RS485NMEATCM.SendData(_address, "GETSP", "+040.000");
                    }
                    state = 0;
                }
                Thread.Sleep(400);  //await Task.Delay(250);// 

            }
        }
        

        /// <summary>
        /// Time function to be called continuously to update View
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void timer_Tick(object sender, EventArgs e)
        {
            Thread t = new Thread(Transmit);
            t.Start();
        }

        public void MessagePopup()
        {
            MessageBox.Show(message);
        }

        private void ExecuteMethod(object parameter)
        {
            double a = Convert.ToDouble(txtSetpoint);
            Debug.WriteLine("Test");
            Debug.WriteLine(a.ToString("000.0000"));
            int coolingModeInt = 0;
            _address = null;
            int _bathNumberInt = Convert.ToInt16(txtBathNumber) + Convert.ToInt16(AddrnComm.EVSTCMAddress1);

            if (txtBathNumber == null)
                _address = AddrnComm.EVSTCMAddress1;
            else
                _address = Convert.ToString(_bathNumberInt - 1);

            if (!String.IsNullOrEmpty(txtSetpoint))
            {
                if ((Convert.ToDouble(txtSetpoint) > 11 && Convert.ToDouble(txtSetpoint) < 105) ||
                    (Convert.ToDouble(txtSetpoint) > 51.8 && Convert.ToDouble(txtSetpoint) < 221))
                {
                    if (MessageBox.Show("Set-point and coolling mode values will be changed. Are you sure you to continue?", "Safety Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                    {
                        //do no stuff
                        return;
                    }
                    else
                    {
                        GlobalParameters.bathUnits = txtUnits;
                        GlobalParameters.clearTemperatureFlag = true;
                        
                        double degreeCSetPoint = 0;
                        if (txtUnits == "°F")
                        {
                            degreeCSetPoint = (Convert.ToDouble(txtSetpoint) - 32) * 5/9 ;
                            Debug.WriteLine("Degrees C inside F = " + degreeCSetPoint + "  TxtSetPoint = " + txtSetpoint);
                        }
                        else
                            degreeCSetPoint = Convert.ToDouble(txtSetpoint);
                        string temperature = degreeCSetPoint.ToString("000.0000");
                        Debug.WriteLine("Temperature = " + temperature);
                        if (!RS485NMEATCM._serialPort.IsOpen)
                        {
                            
                            lock (LockClass._lockKey)
                            {
                                RS485NMEATCM.SendData(_address, "SETBT", temperature);
                            }
                            Thread.Sleep(400);
                            if (txtCoolingMode != currentCoolingMode)
                            {
                                lock (LockClass._lockKey)
                                {
                                    RS485NMEATCM.SendData(_address, "TOGCM", "00000000");
                                }
                             Thread.Sleep(400);
                            }

                        }
                    }
                }
                else
                {
                    MessageBox.Show("Set-point value exceeding the safety limit. 11-105 °C and 51.8-221 °F");
                }
            }
            else
            {
                message = "Please enter set point value";
                Thread t = new Thread(MessagePopup);
                t.Start();
            }
            
        }

        private bool CanExecuteMethod(object parameter)
        {
            if (!String.IsNullOrEmpty(txtSetpoint))
                return true;
            else
                return false;
        }


        private async void ClearOffsetExecuteMethod(object parameter)
        {
            _address = null;
            int _bathNumberInt = Convert.ToInt16(txtBathNumber) + Convert.ToInt16(AddrnComm.EVSTCMAddress1);

            if (txtBathNumber == null)
                _address = AddrnComm.EVSTCMAddress1;
            else
                _address = Convert.ToString(_bathNumberInt - 1);
            if (MessageBox.Show("Offset will be set to 0. Are you sure you want to proceed?", "Safety Check", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
            {
                //do no stuff
                return;
            }
            else
            {
                if (!RS485NMEATCM._serialPort.IsOpen)
                {
                    lock (LockClass._lockKey)
                    {
                        RS485NMEATCM.SendData(_address, "CLRBO", "00000000");
                    }
                    Thread.Sleep(400); //await Task.Delay(250);// Thread.Sleep(400);
                }
            }
            
        }

        private bool ClearOffsetCanExecuteMethod(object parameter)
        {
            return true;
        }
        #endregion
    }
}
