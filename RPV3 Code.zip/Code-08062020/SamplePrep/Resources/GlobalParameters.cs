﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamplePrep.Resources
{
    static class GlobalParameters
    {
        public static string bathSetPoint;
        public static string bathUnits;
        public static bool clearTemperatureFlag;

        //Measurement module settings
        public static string kECorrection;
        public static string maxFlowTimes;
        public static string testMode;
        public static string drainTime;
        public static string equilibriumTime;
        public static string percentageOverfill;
        public static string voidRun;

    }
}
