﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Threading;
using System.Windows;
using System.Diagnostics;

namespace SamplePrep.Resources
{
    public static class RS485NMEATCM
    {
        #region Private Fields
        /// <summary>
        /// Fields to be used in NMEA based RS485 communication
        /// </summary>
        private static string _payload;      //This field contains start char of NMEA style which is $
        private static string _nmeaString;     //This contains the full NMEA string

        public static SerialPort _serialPort;
        private static string _readDataTCM;
        public static ObservableObject Object = new ObservableObject();
        #endregion

        #region Public properties definitions
        /// <summary>
        /// Public property of _payload field
        /// </summary>
        public static string Payload
        {
            get => _payload;
            set => _payload = value;
        }

        /// <summary>
        /// Public property of _nmeaString
        /// </summary>
        public static string NMEAString
        {
            get => _nmeaString;
            set => _nmeaString = value;
        }

        /// <summary>
        /// Public property of _readDataTCM
        /// </summary>
        public static string ReadDataTCM
        {
            get => _readDataTCM;
            set
            {
                _readDataTCM = value;
                //Call OnPropertyChanged function to generate event for ReadDataTCM property changed
                Object.OnPropertyChanged("ReadDataTCM");
            }
        }

        #endregion

        #region Functions of RS485NMEATCM class
        /// <summary>
        /// Constructor to initialise the parameters of the object
        /// </summary>
        /// <param name="address"></param>
        static RS485NMEATCM()
        {
            _serialPort = new SerialPort("COM3", 19200, Parity.None, 8, StopBits.One);
        }

        /// <summary>
        /// This function calculates the checksum of the input parameters provided
        /// </summary>
        /// <param name="NMEAString"></param>
        /// <returns></returns>
        public static byte GetChecksum(string NMEAString)
        {
            byte checksum = 0;
            int i = NMEAString.IndexOf("$") + 1;

            while (true)
            {
                if (NMEAString[i] == '*')
                {

                    break;

                }
                else
                {

                    checksum ^= Convert.ToByte(NMEAString[i]);
                    i++;
                }
            }
            return checksum;
        }

        /// <summary>
        /// Function to convert payload into an NMEA String
        /// </summary>
        /// <param name="payload"></param>
        /// <returns></returns>
        public static  string GetNMEAString(string command, string payload)
        {
            NMEAString = "$" + command + "," + payload + "," + "*";
            NMEAString = NMEAString + GetChecksum(NMEAString).ToString("X2");

            return NMEAString;
        }

        /// <summary>
        /// Event handler for data received through serial port
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void _serialPortDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            /*char[] buffer = new char[20];
            int bytesRead = _serialPort.Read(buffer, 0, 19);
            Debug.WriteLine("Bytes read from Serial {0}", bytesRead);
            if(bytesRead == 19)
                this.ReadDataTCM = new string(buffer);*/
            //Debug.WriteLine("Inside Received Data");
            if (_serialPort.IsOpen)
            {
                try
                {
                    string s = _serialPort.ReadTo("\r");
                    Debug.WriteLine("String length = {0}", s.Length);
                   
                    if (s.Length >= 20)
                        ReadDataTCM = s;
                    _serialPort.Close();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Serial port read error:" + ex);
                }
            }
        }

        /// <summary>
        /// Function to be called to send data to serial port
        /// </summary>
        /// <param name="command"></param>
        /// <param name="data"></param>
        public static void SendData(string address, string command, string data)
        {
            string _nmeaString = GetNMEAString(command, data);

            while (_serialPort.IsOpen) ;
            try
            {
                if (!(_serialPort.IsOpen))
                {
                    _serialPort.Open();
                    _serialPort.ReadTimeout = 500;
                    _serialPort.WriteTimeout = 500;
                    _serialPort.DataReceived += new SerialDataReceivedEventHandler(_serialPortDataReceived);
                }


                byte[] addr = new byte[1];
                addr[0] = Convert.ToByte(address);
                if(_serialPort.IsOpen)
                    _serialPort.Write(addr,0,1);

                //_serialPort.Write(address);
                Thread.Sleep(80);
                if(_serialPort.IsOpen)
                    _serialPort.Write(_nmeaString);
                Debug.WriteLine(_nmeaString);
                Thread.Sleep(80);
                if(_serialPort.IsOpen)
                    _serialPort.Close();
                
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception while writing Data" + ex);
            }
        }

        /// <summary>
        /// Function to send address on serial port for TCM and similarly implemented RS485 slaves
        /// </summary>
        /// <param name="address"></param>
        public static void SendAddress(string address)
        {
            while (_serialPort.IsOpen) ;
            try
            {
                if (!(_serialPort.IsOpen))
                {
                    _serialPort.Open();
                    _serialPort.ReadTimeout = 500;
                    _serialPort.WriteTimeout = 500;
                    _serialPort.DataReceived += new SerialDataReceivedEventHandler(_serialPortDataReceived);

                }
                _serialPort.Write(address);
                //_serialPort.Close();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception while writing Address" + ex);
            }
        }

        /// <summary>
        /// Function to extract address from the incoming NMEAString from Slaves on serial port
        /// </summary>
        /// <param name="NMEAString"></param>
        /// <returns></returns>
        public static string ExtractAddress(string NMEAString)
        {
            int firstIndex = NMEAString.IndexOf("$") + 1;
            int lastIndex = NMEAString.IndexOf("*") - 1;

            return NMEAString.Substring(0, firstIndex - 1);
        }

        /// <summary>
        /// Function to extract data from NMEA the incoming NMEA string from slave
        /// </summary>
        /// <param name="NMEAString"></param>
        /// <returns></returns>
        public static string ExtractData(string NMEAString)
        {
            int firstIndex = NMEAString.IndexOf("$") + 1;
            int commaIndex = NMEAString.IndexOf(",");
            int lastIndex = NMEAString.IndexOf("*") - 1;

            string payload = NMEAString.Substring(firstIndex, lastIndex - firstIndex + 1);
            return payload;
        }

        /// <summary>
        /// Function to validate checksum of incoming NMEAString
        /// </summary>
        /// <param name="NMEAString"></param>
        /// <returns></returns>
        public static bool ValidateChecksum(string NMEAString)
        {
            
            int firstIndex = NMEAString.IndexOf("$") + 1;
            int lastIndex = NMEAString.IndexOf("*") - 1;
            string payload = NMEAString.Substring(firstIndex, lastIndex - firstIndex + 1);

            if (GetChecksum(NMEAString).ToString("X2") == NMEAString.Substring(lastIndex+2,2))
            {
                return true;  
            }
            else
                return false;
        }
        #endregion
    }
}
