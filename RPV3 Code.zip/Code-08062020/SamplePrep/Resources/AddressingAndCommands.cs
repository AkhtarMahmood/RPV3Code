﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamplePrep.Resources
{
    class AddressingAndCommands
    {
        #region EVSTCM Address, Commands, and Parameters
        /// <summary>
        /// Addresses of device nodes
        /// </summary>
        public string EVSTCMAddress1   =  "128";
        public string EVSTCMAddress2   =  "129";
        public string EVSTCMAddress3   =  "130";
        public string EVSTCMAddress4   =  "131";
        public string EVSTCMAddress5   =  "132";
        public string EVSTCMAddress6   =  "133";

        /// <summary>
        /// Commands of EVS TCM
        /// </summary>
        public string EVSTCMGetSetPoint = "GETSP";
        public string EVSTCMGetBathOffset = "GETBO";
        public string EVSTCMGetBathTemperature = "GETBT";
        public string EVSTCMSetBathReference = "SETBO";
        public string EVSTCMGetBathStatus = "GETSB";

        //Settings page commands

        public string EVSTCMSetSetPoint = "SETBT";
        public string EVSTCMSetChillerMode = "SETCM";
        public string EVSTCMClearOffset = "CLRBO";
        public double ReferenceAndActualOffset = 0.3;

        #endregion

        #region Measurement Address, Commands, and Parameters
        /// <summary>
        /// Address of Measurement devices
        /// </summary>
        /// 
        public string MeasurementAddressOffset = "134";
        public string MeasurementAddress1 = "134";
        public string MeasurementAddress2 = "135";
        public string MeasurementAddress3 = "136";
        public string MeasurementAddress4 = "137";
        public string MeasurementAddress5 = "138";
        public string MeasurementAddress6 = "139";

        //Measurement Sensor Node Commands
        public string MeasurementSensorNodeAddress1 = "140";
        public string MeasurementSensorNodeAddress2 = "141";


        //Measurement page commands for head 1
        public string MeasurementPosition1Command               = "STPC1";
        public string MeasurementGetTimer1Command               = "GETT1";
        public string MeasurementResetTimer1Command             = "RSTT1";
        public string MeasurementResetHead1Command              = "RSTH1";
        public string MeasurementSetNumberOfCleaningSolvents1   = "STNS1";
        public string MeasurementGetNumberOfCleaningSolvents1   = "GTNS1";
        public string MeasurementEnableCleanHead1               = "ENCH1";
        public string MeasurementAbortCleanHead1                = "ABCH1";
        public string MeasurementSetSampleExtractionLoop1        = "STAL1";
        public string MeasurementGetSampleExtractionLoop1        = "GTAL1";
        public string MeasurementSetDryingLoop1                  = "STDL1";
        public string MeasurementGetDryingLoop1                  = "GTDL1";
        public string MeasurementSetSolventCleanLoop1            = "STSL1";
        public string MeasurementGetSolventCleanLoop1            = "GTSL1";

        //Measurement page commands for head 2
        public string MeasurementPosition2Command   = "STPC2";
        public string MeasurementGetTimer2Command   = "GETT2";
        public string MeasurementResetTimer2Command = "RSTT2";
        public string MeasurementResetHead2Command  = "RSTH2";


        //Measurement Sensor Node Commands
        public string MeasurementGetSensor1Command = "GETA0";
        public string MeasurementGetSensor2Command = "GETA1";
        public string MeasurementGetSensor3Command = "GETA2";
        public string MeasurementGetSensor4Command = "GETA3";
        public string MeasurementGetSensor5Command = "GETA4";
        public string MeasurementGetSensor6Command = "GETA5";
        //PB0 Enable PB2 TX, PB3 RX


        public double MeasurementOverfillPercentage     = 11;
        public double MeasurementDrainingTimePercentage = 13;

        //Measurement page data
        public string MeasurementPushSampleData                 = "10100000";
        public string MeasurementHoldOrEquilibriumSampleData    = "00000000";
        public string MeasurementSettleSampleData               = "01000000";
        public string MeasurementReleaseOrLoadSampleData        = "01100000";
        public string MeasurementDummyCommandValue = "00000000";

        #endregion

        #region Communication
        public int [] ExcmEnable ={ 0x0100, 0x0000, 0x0000, 0x0000, 0x00, 0x00, 0x00, 0x00 };
        public int [] ExcmEnableOperation = { 0x0300, 0x0000, 0x0000, 0x0000, 0x00, 0x00, 0x00, 0x00 };
        public int [] ExcmHoming = { 0x4300, 0x0000, 0x0000, 0x0000, 0x00, 0x00, 0x00, 0x00 };

        #endregion

        #region
        //Object to perform locking operations between threads
        public object x = new object();
        #endregion

    }
}
