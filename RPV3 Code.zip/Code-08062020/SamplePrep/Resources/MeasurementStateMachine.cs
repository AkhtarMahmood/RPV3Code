﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace SamplePrep.Resources
{
    class Context
    {
        //A Reference to the current state
        private State _state = null;

        public Context(State state)
        {
            this.TransitionTo(state);
        }

        public void TransitionTo(State state)
        {
            Debug.WriteLine($"Context: Transition to {state.GetType().Name}");
            this._state = state;
            this._state.SetContext(this);
        }

        public void RequestIdle()
        {
            this._state.HandleIdle();
        }

        public void RequestSampleLoading()
        {
            this._state.HandleSampleLoading();
        }
        public void RequestSampleEquilibrium()
        {
            this._state.HandleSampleEquilibrium();
        }

        public void RequestSampleResting()
        {
            this._state.HandleSampleResting();
        }
        public void RequestSamplePushUp()
        {
            this._state.HandleSamplePushUp();
        }

        public void RequestOverFilling()
        {
            this._state.HandleOverFilling();
        }
        public void RequestSampleHolding()
        {
            this._state.HandleSampleHolding();
        }

        public void RequestAirRelease()
        {
            this._state.HandleAirRelease();
        }
        public void RequestSampleRelease()
        {
            this._state.HandleSampleRelease();
        }

    }
    abstract class State
    {
        protected Context _context;
        //protected RS485NMEATCM RS485NMEATCM = new RS485NMEATCM();
        //Object of Address class for the addressing of temperature control bath
        protected AddressingAndCommands AddrnComm = new AddressingAndCommands();
        protected static object x = new object();


        public void SetContext(Context context)
        {
            this._context = context;
        }

        public abstract void HandleIdle();
        public abstract void HandleSampleLoading();
        public abstract void HandleSampleEquilibrium();
        public abstract void HandleSampleResting();
        public abstract void HandleSamplePushUp();
        public abstract void HandleOverFilling();
        public abstract void HandleSampleHolding();
        public abstract void HandleAirRelease();
        public abstract void HandleSampleRelease();

    }

    class ConcreteStateIdle : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
            lock(x)
            {
                RS485NMEATCM.SendData(AddrnComm.MeasurementAddress1, AddrnComm.MeasurementResetTimer1Command, AddrnComm.MeasurementPushSampleData);
                RS485NMEATCM.SendData(AddrnComm.MeasurementAddress2, AddrnComm.MeasurementResetTimer2Command, AddrnComm.MeasurementPushSampleData);
                Debug.WriteLine("Timers for head1 and head2 reseted");
            }
        }
    
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateIdle wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
    class ConcreteStateSampleLoading : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateSampleLoading wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
        }
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateSampleLoading wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateSampleLoading wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
    class ConcreteStateSampleEquilibrium : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
        }
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateSampleEquilibrium wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
    class ConcreteStateSampleResting : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
        }
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateSampleResting wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
    class ConcreteStateSamplePushUp : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
        }
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateSamplePushUp wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
    class ConcreteStateOverFilling : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
        }
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateOverFilling wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
    class ConcreteStateSampleHolding : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
        }
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateSampleHolding wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
    class ConcreteStateAirRelease : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
        }
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateAirRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
    class ConcreteStateSampleRelease : State
    {
        public override void HandleIdle()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateIdle());
        }
        public override void HandleSampleLoading()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleLoading());
        }
        public override void HandleSampleEquilibrium()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleEquilibrium());
        }
        public override void HandleSampleResting()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleResting());
        }
        public override void HandleSamplePushUp()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSamplePushUp());
        }
        public override void HandleOverFilling()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateOverFilling());
        }

        public override void HandleSampleHolding()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleHolding());
        }
        public override void HandleAirRelease()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateAirRelease());
        }
        public override void HandleSampleRelease()
        {
            Debug.WriteLine("ConcreteStateSampleRelease wants to change the state of the context.");
            this._context.TransitionTo(new ConcreteStateSampleRelease());
        }
    }
}
