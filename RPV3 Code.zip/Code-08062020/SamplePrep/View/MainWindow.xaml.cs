﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SamplePrep.ViewModel;
using SamplePrep.View;
using System.Diagnostics;
using System.IO.Ports;

namespace SamplePrep
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        object ViscometerMeasurementPageContent = new ViscometerMeasurementPage();
        object ReferenceTemperaturePageContent = new ReferenceTemperaturePage();
        object SettingsPageContent = new SettingsPage();
        //object ResultsPageContent = new ResultsPage();
        //object SamplePreparationPageContent = new SamplePreparation();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ReferenceTemperature_Click(object sender, RoutedEventArgs e)
        {
            //Main.Content = new ReferenceTemperaturePage();
            Main.Content = ReferenceTemperaturePageContent; //--Uncomment this one
            
            //MainWindow app = new MainWindow();
            //ReferenceTemperaturePage context = new ReferenceTemperaturePage();
            //context.DataContext = context;
            //context.Show();
            //Main.Navigate(new System.Uri("SamplePrep.View.ReferenceTemperaturePage.xaml",
            //UriKind.RelativeOrAbsolute));
            //NavigationService nav = NavigationService.GetNavigationService(this);
            //nav.Navigate(new System.Uri("ReferenceTemperature.xaml", UriKind.RelativeOrAbsolute));

            //ReferenceTemperature page = new ReferenceTemperature();
            //Main.Navigate(page);
            //Main.NavigationService.Navigate(new Uri("ReferenceTemperature.xaml", UriKind.Relative));
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            //Main.Content = new SettingsPage();
            Main.Content = SettingsPageContent;  //Uncomments this one
        }

        private void SamplePreparation_Click(object sender, RoutedEventArgs e)
        {

            //Main.Content = new SamplePreparation();
            //Main.Content = SamplePreparationPageContent;
        }

        private void ViscometerMeasurement_Click(object sender, RoutedEventArgs e)
        {
            //Main.Navigate(new System.Uri("ViscometerMeasurementPage.xaml",
            //UriKind.RelativeOrAbsolute));
            //Main.Content = new ViscometerMeasurementPage();
            Main.Content = ViscometerMeasurementPageContent;
            //Main.Navigate(new ViscometerMeasurementPage());
            Debug.WriteLine("Viscmeter Measuremennt Activated");
            //Debug.WriteLine(Main.CurrentSource.ToString());
            
        }

        private void Results_Click(object sender, RoutedEventArgs e)
        {
            //Main.Content = new ResultsPage();
            //Main.Content = ResultsPageContent;
        }

        private void PowerOff_Click(object sender, RoutedEventArgs e)
        {
            //Main.Content = new ResultsPage();
            if (MessageBox.Show("Close Application?", "Power off", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
            {
                //do no stuff
            }
            else
            {
                //do yes stuff
                //this.Close();
                //Application.Current.Shutdown();
                Environment.Exit(Environment.ExitCode);
            }

            
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            // Shutdown the application.
            //Application.Current.Shutdown();
            Environment.Exit(Environment.ExitCode);
            // OR You can Also go for below logic
            // Environment.Exit(0);
        }

        /*  base.OnStartup(e);

          MainWindow app = new MainWindow();
          ReferenceTemperatureViewModel context = new ReferenceTemperatureViewModel();
          app.DataContext = context;
          app.Show();*/
    }
}
